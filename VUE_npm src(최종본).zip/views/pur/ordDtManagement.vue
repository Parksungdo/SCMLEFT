<template>
  <form id="myForm" action="" method="">
    <input type="hidden" id="currentPage" value="" />
    <input type="hidden" id="currentPageModal" value="" />

    <div id="mask"></div>
    <div id="wrap_area">
      <h2 class="hidden">컨텐츠 영역</h2>
      <div id="container">
        <ul>
          <li class="contents">
            <!-- contents -->
            <h3 class="hidden">contents 영역</h3>
            <!-- content -->
            <div class="content">
              <p class="Location">
                <a href="/dashboard/dashboard.do" class="btn_set home"
                  >메인으로</a
                >
                <a class="btn_nav">기업고객</a>
                <span class="btn_nav bold">주문내역 관리</span>
                <a href="" class="btn_set refresh">새로고침</a>
              </p>

              <p class="conTitle">
                <span>주문내역 관리</span>
              </p>

              <div id="orderList">
                <div
                  class="conTitle"
                  style="margin: 0 25px 10px 0"
                  align="center"
                >
                  <select name="searchKey" id="searchKey" v-model="searchKey">
                    <option value="all" id="option1">전체</option>
                    <option value="cpname" id="option1">업체명</option>
                    <option value="pdname" id="option2">제품명</option>
                  </select>
                  <input
                    type="text"
                    style="width: 160px; height: 30px"
                    id="searchWord"
                    name="searchWord"
                    placeholder="검색어를 입력하세요."
                    onkeypress="if( event.keyCode == 13 )"
                    v-model="searchWord"
                  />
                  <input
                    type="date"
                    style="width: 160px; height: 30px"
                    id="sdate"
                    name="sdate"
                    onkeypress="if( event.keyCode == 13 )"
                    v-model="sdate"
                  />
                  <input
                    type="date"
                    style="width: 160px; height: 30px"
                    id="edate"
                    name="edate"
                    onkeypress="if( event.keyCode == 13 )}"
                    v-model="edate"
                  />
                  <a
                    class="btn btn-primary mx-2"
                    name="search"
                    @click="getList()"
                    ><span>검 색</span></a
                  >
                  <!-- enter입력하면 검색실행   -->

                  <span style="margin: 10px">
                    <input type="checkbox" id="depositCheck" /> 승인
                  </span>
                </div>
                <table class="col">
                  <caption>
                    caption
                  </caption>
                  <colgroup>
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="10%" />
                    <col width="20%" />
                    <col width="10%" />
                    <col width="10%" />
                  </colgroup>

                  <thead>
                    <tr>
                      <th scope="col">발주번호</th>
                      <th scope="col">발주회사</th>
                      <th scope="col">발주제품</th>
                      <th scope="col">제품명</th>
                      <th scope="col">발주수량</th>
                      <th scope="col">날짜</th>
                      <th scope="col">입금확인</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      v-for="item in listitem"
                      :key="item.bord_CODE"
                      @click="getmodal(item.jord_CODE, item.jord_IN)"
                    >
                      <td>{{ item.jord_CODE }}</td>
                      <td>{{ item.loginID }}</td>
                      <td>{{ item.model_NAME }}</td>
                      <td>{{ item.pd_NAME }}</td>
                      <td>{{ item.jord_AMT }}</td>
                      <td>{{ item.jord_DATE }}</td>
                      <td>
                        <templete v-if="item.jord_IN == '1'">
                          <div style="color: skyblue; font-weight: bold">
                            입금
                          </div>
                        </templete>
                        <templete v-else>
                          <div style="color: red; font-weight: bold">
                            미입금
                          </div>
                        </templete>
                      </td>
                    </tr>
                  </tbody>
                </table>

                <!-- 페이징 처리 -->
                <div id="comnGrpCodPagination">
                  <paginate
                    class="justify-content-center"
                    v-model="currentPage"
                    :page-count="totalPage"
                    :page-range="5"
                    :margin-pages="0"
                    :click-handler="getList"
                    :prev-text="'Prev'"
                    :next-text="'Next'"
                    :container-class="'pagination'"
                    :page-class="'page-item'"
                  >
                  </paginate>
                </div>
              </div>
              <!-- Modal 시작 -->
            </div>
            <!--// content -->
            <h3 class="hidden">풋터 영역</h3>
          </li>
        </ul>
      </div>
    </div>
  </form>
</template>

<script>
import Paginate from 'vuejs-paginate-next';

export default {
  data: function () {
    return {
      listitem: [],
      pageSize: 10,
      currentPage: 1,
      totalPage: 1,
      totalCnt: 0,
      searchWord: '',
      sdate: '',
      edate: '',
      flag: true,
      action: 'U',
      searchKey: 'all',
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.getList();
  },
  methods: {
    getList: function () {
      let vm = this;
      console.log(this.sdate);
      console.log(this.edate);

      let params = new URLSearchParams();
      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);
      params.append('searchWord', this.searchWord);
      params.append('sdate', this.sdate);
      params.append('edate', this.edate);
      params.append('searchKey', this.searchKey);

      this.axios
        .post('/pur/ordDtManagementList.do', params)
        .then(function (response) {
          console.log(response);
          vm.listitem = response.data.listOrdDtManagement;
          vm.totalCnt = response.data.totalCnt;
          vm.totalPage = vm.page();
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    getmodal: function (jordCode, jord_IN) {
      let vm = this;
      let params = new URLSearchParams();

      console.log(jordCode);
      params.append('action', this.action);
      params.append('jordCode', jordCode);
      if (jord_IN == 1) {
        this.flag = false;
      } else {
        this.flag = true;
      }

      if (!this.flag) {
        this.$swal('이미 입금되었습니다');
      } else {
        this.$swal
          .fire({
            title: '입금 하시겠습니까?',
            showDenyButton: true,
            confirmButtonText: '예',
            denyButtonText: `아니오`,
          })
          .then((result) => {
            if (result.isConfirmed) {
              this.axios
                .post('/pur/updateList.do', params)
                .then(function (response) {
                  let msg = response.data.result;
                  console.log(response);
                  if (msg == 'UPDATED') {
                    vm.$swal.fire('입금완료', '', 'success');
                  } else {
                    vm.$swal.fire('입금실패', '', 'error');
                  }
                  vm.getList();
                });
            } else {
              this.$swal.fire('입금취소...', '', 'error');
            }
          });
      }
    },
  },
};
</script>
