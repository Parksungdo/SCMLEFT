<template>
  <div id="orderReturn">
    <div class="content">
      <p class="Location">
        <a href="#" class="btn_set home">메인으로</a>
        <a href="#" class="btn_nav">기업고객</a>
        <span class="btn_nav bold">반품내역 관리</span>
        <a onClick="../system/comnCodMgr.vue" class="btn_set refresh"
          >새로고침</a
        >
      </p>

      <p class="conTitle" id="searcharea">
        <span>반품내역 관리</span>
        <span class="fr">
          <select v-model="searchKey">
            <option disabled selected value="">검색요건</option>
            <option value="cpname" id="option1">업체명</option>
            <option value="pdname" id="option2">제품명</option>
          </select>
          <input
            type="text"
            style="width: 160px; height: 30px"
            v-model="searchWord"
            placeholder="검색어를 입력하세요."
            onkeypress="if( event.keyCode == 13 ){refundList();}"
          />
          <input
            type="date"
            style="width: 160px; height: 30px"
            v-model="sdate"
            onkeypress="if( event.keyCode == 13 ){refundList();}"
          />
          <input
            type="date"
            style="width: 160px; height: 30px"
            v-model="edate"
            onkeypress="if( event.keyCode == 13 ){refundList();}"
          />
          <a class="btn btn-primary mx-2" @click="refundSearch()" name="search"
            ><span>검 색</span></a
          >
        </span>
      </p>
      <table class="col">
        <colgroup>
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
          <col width="10%" />
          <col width="10%" />
          <col width="10%" />
          <col width="10%" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">반품번호</th>
            <th scope="col">반품회사</th>
            <th scope="col">반품제품</th>
            <th scope="col">반품수량</th>
            <th scope="col">날짜</th>
            <th scope="col">반품금액</th>
            <th scope="col">송금여부</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in listitem"
            :key="item.re_CODE"
            @click="updateOut(item.re_CODE, item.re_OUT)"
          >
            <td>{{ item.re_CODE }}</td>
            <td>{{ item.loginID }}</td>
            <td>{{ item.model_NAME }}</td>
            <td>{{ item.re_AMT }}</td>
            <td>{{ item.re_DATE }}</td>
            <td>{{ item.pd_PRICE }}</td>
            <td>
              <span
                v-if="item.re_OUT == '0'"
                style="color: blue; font-weight: bold"
                >미송금</span
              >
              <span
                v-else-if="item.re_OUT == '1'"
                style="color: red; font-weight: bold"
                >송금완료</span
              >
            </td>
          </tr>
          <tr v-if="listitem.length == 0">
            <td colspan="7">검색된 데이터가 없습니다.</td>
          </tr>
        </tbody>
      </table>

      <div id="comnGrpCodPagination">
        <paginate
          class="justify-content-center"
          v-model="currentPage"
          :page-count="totalPage"
          :page-range="10"
          :margin-pages="0"
          :click-handler="refundSearch"
          :prev-text="'Prev'"
          :next-text="'Next'"
          :container-class="'pagination'"
          :page-class="'page-item'"
        >
        </paginate>
      </div>
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next'; // 페이징 처리

export default {
  data: function () {
    return {
      listitem: [],
      searchKey: '',
      searchWord: '',
      sdate: '',
      edate: '',
      currentPage: 1, //  현재 페이지
      listCount: 10, // 리스트 뿌릴 사이즈
      totalPage: 1, // 페이징
      totalCnt: 0, // 리스트의 총 사이즈
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    /* Vue에서는 el방식이 안먹혀서 mounted에서 search 호출해서 리스트를 뿌려줘야 한다. */
    this.refundSearch();
  },
  methods: {
    // 리스트 불러오기
    refundSearch: function () {
      console.log('enterKey');

      let vm = this;
      let params = new URLSearchParams();

      if ((this.searchKey == '' || this.searchWord == '') && this.sdate != '')
        return this.$swal('검색구분을 선택하고 검색어를 입력 후 검색해주세요.');
      if (this.edate.replaceAll('-', '') - this.sdate.replaceAll('-', '') < 0)
        return this.$swal('올바른 날짜를 선택해주세요.');

      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.listCount);
      params.append('deliveryDoneCheck', this.deliveryDoneCheck);
      params.append('searchKey', this.searchKey);
      params.append('searchWord', this.searchWord);
      params.append('sdate', this.sdate);
      params.append('edate', this.edate);

      this.axios
        .post('/pur/refundList.do', params)
        .then(function (response) {
          console.log(response.data);

          vm.listitem = response.data.listRefund;
          vm.totalCnt = response.data.totalCnt;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    // 디테일내역
    updateOut: function (reCode, reOut) {
      console.log('detailview');

      const vm = this;
      let params = new URLSearchParams();

      if (reOut == '1') return this.$swal('송금처리가 완료된 지시서입니다.');

      this.$swal
        .fire({
          title: '송금완료 처리를 하시겠습니까??',
          showDenyButton: true,
          showCancelButton: false,
          confirmButtonText: '네',
          denyButtonText: '아니요',
        })
        .then((result) => {
          if (result.isConfirmed) {
            params.append('action', 'U');
            params.append('recode', reCode);

            this.axios
              .post('/pur/refundUpdate.do', params)
              .then(function (response) {
                console.log(response.data);
                vm.refundSearch();
              })
              .catch(function (error) {
                alert('에러! API 요청에 오류가 있습니다. ' + error);
              });
          }
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.listCount;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
  },
};
</script>
