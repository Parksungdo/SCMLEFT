<template>
  <div id="grpInfoWrap" style="width: 53.8rem">
    <dl>
      <dt>
        <strong>발주지시서 상세보기</strong>
      </dt>
      <dd class="content">
        <table class="col">
          <colgroup>
            <col width="8%" />
            <col width="10%" />
            <col width="10%" />
            <col width="20%" />
            <col width="8%" />
            <col width="10%" />
            <col width="10%" />
            <col width="10%" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col">발주번호</th>
              <th scope="col">납품업체</th>
              <th scope="col">납품 담당자</th>
              <th scope="col">제품명</th>
              <th scope="col">수량</th>
              <th scope="col">단가</th>
              <th scope="col">합계</th>
              <th scope="col">창고명</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{{ bordCode }}</td>
              <td>{{ companyName }}</td>
              <td>{{ name }}</td>
              <td>{{ pdName }}</td>
              <td>{{ bordAmt }}</td>
              <td>{{ pdPrice }}</td>
              <td>{{ total }}</td>
              <td>{{ whName }}</td>
            </tr>
          </tbody>
        </table>
        <div class="btn_areaC mt30">
          <a
            class="btn btn-primary mx-2"
            v-on:click="updBordDirection()"
            v-show="purOut"
            ><span>송금확인</span></a
          >
          <a class="btn btn-primary mx-2" @click="modalClose()"
            ><span>닫기</span></a
          >
        </div>
      </dd>
    </dl>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';

export default {
  props: { bordCode: Number },
  data: function () {
    return {
      //DetailbordCode: this.bordCode,
      pageNum: 1,
      listCount: 10,
      DetailbordCode: this.bordCode,
      bordCodeDetail: '',
      purOut: true,
      bordType: '3',
      companyName: '',
      name: '',
      pdName: '',
      bordAmt: '',
      pdPrice: '',
      total: '',
      whName: '',
    };
  },
  mounted() {
    this.search();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      //params.append('DetailbordCode', this.DetailbordCode);
      params.append('pageNum', this.pageNum);
      params.append('listCount', this.listCount);
      params.append('bordCode', this.DetailbordCode);

      console;

      this.axios
        .post('/pur/searchPurDirectionDetail', params)
        .then(function (response) {
          console.log(response.data);
          vm.bordCodeDetail = response.data.result.purDirectionList[0].bordCode;
          vm.companyName = response.data.result.purDirectionList[0].companyName;
          vm.name = response.data.result.purDirectionList[0].name;
          vm.pdName = response.data.result.purDirectionList[0].pdName;
          vm.bordAmt = response.data.result.purDirectionList[0].bordAmt;
          vm.pdPrice = response.data.result.purDirectionList[0].pdPrice;
          vm.total = response.data.result.purDirectionList[0].total;
          vm.whName = response.data.result.purDirectionList[0].whName;
          vm.totalCnt = response.data.result.purDirectionCount;
        })
        .catch(function (error) {
          alert('에러' + error);
        });
    },
    updBordDirection: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      //params.append('DetailbordCode', this.DetailbordCode);
      params.append('bordType', this.bordType);
      params.append('bordCode', this.DetailbordCode);

      console;

      this.axios
        .post('/pur/updateBorderDirection', params)
        .catch(function (error) {
          alert('에러' + error);
        });
      closeModal();
    },
    modalClose: function () {
      closeModal();
    },
  },
};
</script>

<style>
#grpInfo {
  border-collapse: separate;
  border-spacing: 20px;
}
#grpInfoWrap {
  background-color: #fff;
  padding: 3rem;
  border-radius: 10px;
  border: 2px solid rgb(59, 59, 59);
}
</style>
