<template>
  <form id="myForm" action="" method="">
    <input type="hidden" id="currentPage" value="" />
    <input type="hidden" id="currentPageModal" value="" />
    <!-- 모달 배경 -->
    <div id="mask"></div>
    <div id="wrap_area">
      <h2 class="hidden">컨텐츠 영역</h2>
      <div id="container">
        <ul>
          <li class="contents">
            <!-- contents -->
            <h3 class="hidden">contents 영역</h3>
            <!-- content -->

            <!-- 타이틀 영역 -->
            <div class="content" style="margin-bottom: 20px">
              <p class="Location">
                <a href="../dashboard/dashboard.do" class="btn_set home"
                  >메인으로</a
                >
                <span class="btn_nav bold">메인</span>
                <a href="../dashboard/dashboard.do" class="btn_set refresh"
                  >새로고침</a
                >
              </p>
              <div>
                <p class="conTitle" style="margin-bottom: 1%">
                  <span>매출현황</span> <span class="fr"> 관련 자료 </span>
                </p>
              </div>

              <!-- 주문상태 -->
              <div style="height: 15rem; margin-bottom: 3rem">
                <table class="col">
                  <thead>
                    <tr>
                      <th scope="col">기업이름</th>
                      <th scope="col">매출금액</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      v-for="item in listitem"
                      :key="item.company"
                      @click="whclick(item.company)"
                    >
                      <td>{{ item.company }}</td>
                      <td>{{ item.macul }}</td>
                    </tr>
                  </tbody>
                </table>
                <div id="comnGrpCodPagination">
                  <paginate
                    class="justify-content-center"
                    v-model="pageNum"
                    :page-count="totalPage"
                    :page-range="5"
                    :margin-pages="0"
                    :click-handler="getList"
                    :prev-text="'Prev'"
                    :next-text="'Next'"
                    :container-class="'pagination'"
                    :page-class="'page-item'"
                  >
                  </paginate>
                </div>
              </div>

              <div style="height: 15rem; margin-bottom: 3rem">
                <table class="col">
                  <thead>
                    <tr>
                      <th scope="col">기업이름</th>
                      <th scope="col">제품명</th>
                      <th scope="col">거래금액</th>
                      <th scope="col">거래날짜</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="item in listitem1" :key="item.company">
                      <td>{{ item.company }}</td>
                      <td>{{ item.model_name }}</td>
                      <td>{{ item.price }}</td>
                      <td>{{ item.dtldate }}</td>
                    </tr>
                  </tbody>
                </table>
                <div id="comnGrpCodPagination">
                  <paginate
                    class="justify-content-center"
                    v-model="pageNum1"
                    :page-count="totalPage1"
                    :page-range="5"
                    :margin-pages="0"
                    :click-handler="getlistdeteil"
                    :prev-text="'Prev'"
                    :next-text="'Next'"
                    :container-class="'pagination'"
                    :page-class="'page-item'"
                  >
                  </paginate>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </form>
</template>

<script>
import Paginate from 'vuejs-paginate-next';

export default {
  data: function () {
    return {
      listitem: [],
      pageNum: 1,
      listCount: 10,
      totalPage: 1,
      totalCnt: 0,
      comName: '',
      stDate: '',
      edDate: '',

      listitem1: [],
      pageNum1: 1,
      listCount1: 10,
      totalPage1: 1,
      totalCnt1: 0,
      click_comName2: '',
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.getList();
  },

  methods: {
    getList: function () {
      let vm = this;

      let params = new URLSearchParams();
      params.append('clickpagenum', this.pageNum);
      params.append('pageSize', this.listCount);
      params.append('comName', this.comName);
      params.append('stDate', this.stDate);
      params.append('edDate', this.edDate);

      this.axios.post('/cmp/salesStatusvue', params).then(function (response) {
        console.log(response.data);
        vm.listitem = response.data.SalesStatusModel;
        vm.totalCnt = response.data.transactionHistoryCnt;
        vm.totalPage = vm.page();
      });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.listCount;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },

    whclick: function (company) {
      //alert('whclick : ' + comName2 + ': ' + comName2);
      this.click_comName2 = company;

      this.getlistdeteil();
    },

    getlistdeteil: function () {
      console.log('현황');
      console.log(this.click_comName2);
      let vm = this;
      let params = new URLSearchParams();

      params.append('clickpagenum', this.pageNum1);
      params.append('pageSize', this.listCount1);
      params.append('comName2', this.click_comName2);

      this.axios.post('/cmp/salesStatusdtl', params).then(function (response) {
        console.log(response);
        vm.listitem1 = response.data.dtlList;
        vm.totalCnt1 = response.data.dtlLisCnt;
        vm.totalPage1 = vm.page1();
      });
    },
    page1: function () {
      var total1 = this.totalCnt1;
      var page1 = this.listCount1;
      var xx1 = total1 % page1;
      var result1 = parseInt(total1 / page1);

      if (xx1 == 0) {
        return result1;
      } else {
        result1 = result1 + 1;
        return result1;
      }
    },
  },
};
</script>
