<template>
  <form id="myForm" action="" method="">
    <div id="mask"></div>
    <div id="wrap_area">
      <div id="container">
        <ul>
          <li class="contents">
            <div class="content">
              <p class="Location">
                <a href="../dashboard/dashboard.do" class="btn_set home"
                  >메인으로</a
                >
                <span class="btn_nav bold">승인</span>
                <span class="btn_nav bold">구매승인</span>
                <a href="../system/comnCodMgr.do" class="btn_set refresh"
                  >새로고침</a
                >
              </p>
              <p class="conTitle">
                <span>구매 승인</span>

                <!-- 검색영역 -->
                <span class="fr" id="spanSearchBar">
                  <span> 제품명 </span>
                  <input
                    type="text"
                    style="width: 300px; height: 25px"
                    id="searchvalue"
                    name="searchvalue"
                    v-model="keyword"
                  />
                  <input type="date" id="sdate" />
                  <span> ~ </span>
                  <input type="date" id="edate" />
                  <a
                    class="btn btn-primary mx-2"
                    id="btnsearch"
                    name="btn"
                    @click="searchList()"
                  >
                    <span>검 색</span>
                  </a>
                </span>
              </p>

              <!-- 발주승인 테이블 영역 -->
              <div id="divOrderConfirmList">
                <table class="col">
                  <colgroup>
                    <col width="10%" />
                    <col width="20%" />
                    <col width="10%" />
                    <col width="15%" />
                    <col width="10%" />
                    <col width="20%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th scope="col">발주업체명</th>
                      <th scope="col">제품명</th>
                      <th scope="col">수량</th>
                      <th scope="col">금액</th>
                      <th scope="col">구매일자</th>
                      <th scope="col">구매 승인</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="item in items" :key="item.bordCode">
                      <td>{{ item.companyName }}</td>
                      <td>{{ item.pdName }}</td>
                      <td>{{ item.bordAmt }}</td>
                      <td>{{ item.total }}</td>
                      <td>{{ item.dirDate }}</td>
                      <td v-if="item.bordType == 0">
                        <a
                          class="btn btn-primary mx-2"
                          v-on:click="confirmBorder('1', item.bordCode)"
                        >
                          <span>승인</span>
                        </a>
                        <a
                          class="btn btn-danger mx-2"
                          v-on:click="confirmBorder('2', item.bordCode)"
                        >
                          <span>반려</span>
                        </a>
                      </td>
                      <td
                        v-if="item.bordType != 0"
                        style="color: red; font-weight: bold"
                      >
                        {{ item.typeName }}
                      </td>
                    </tr>
                    <tr v-if="items.length == 0">
                      <td colspan="6">검색된 데이터가 없습니다.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div id="comnGrpCodPagination">
                <paginate
                  class="justify-content-center"
                  v-model="pageNum"
                  :page-count="totalPage"
                  :page-range="5"
                  :margin-pages="0"
                  :click-handler="searchList"
                  :prev-text="'Prev'"
                  :next-text="'Next'"
                  :container-class="'pagination'"
                  :page-class="'page-item'"
                >
                </paginate>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </form>
</template>

<script>
import Paginate from 'vuejs-paginate-next';

export default {
  data: function () {
    return {
      startDate: '',
      endDate: '',
      items: [],
      pageNum: 1,
      listCount: 10,
      totalPage: 1,
      totalCnt: 0,
      keyword: '',
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.searchList();
  },
  methods: {
    //리스트 뿌려주기
    // 페이징시 왜 자꾸 리스트가 추가됨 :: 해결 :: key를 companyName으로 줬음. bordCode로 변경 후 해결
    searchList: function () {
      let vm = this;

      let params = new URLSearchParams();
      params.append('pageNum', this.pageNum);
      params.append('listCount', this.listCount);
      params.append('keyword', this.keyword);
      params.append('startDate', this.startDate);
      params.append('endDate', this.endDate);

      this.axios
        .post('/cmp/searchOrderConfirmlist', params)
        .then(function (response) {
          console.log(response.data);

          vm.items = response.data.result.orderConfirmList;
          vm.totalCnt = response.data.result.orderConfirmCount;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('리스트 에러. ' + error);
        });
    },
    //페이지 처리
    page: function () {
      var total = this.totalCnt;
      console.log('totalcnt:' + total);
      var page = this.listCount;
      console.log('page' + page);
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    confirmBorder: function (bordType, bordCode) {
      let vm = this;

      let params = new URLSearchParams();
      params.append('bordCode', bordCode);
      params.append('bordType', bordType);

      this.axios
        .post('/cmp/updateBorderType', params)
        .then(function (response) {
          let msg = response.data.message;
          let msg1 = '';
          if (bordType == 1) {
            msg1 = '승인';
          } else {
            msg1 = '반려';
          }
          vm.$swal.fire(msg1 + msg);
          vm.vueoder();
        });
    },
  },
};
</script>
