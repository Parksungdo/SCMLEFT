<template>
  <div id="comnCodMgr">
    <p class="Location">
      <router-link :to="'/dashboard/home'">
        <a class="btn_set home"></a>
      </router-link>
      <span class="btn_nav bold">승인</span>
      <span class="btn_nav bold">반품 승인</span>
      <router-link :to="'/dashboard/cmp/refundConfirm'">
        <a class="btn_set refresh">새로고침</a>
      </router-link>
    </p>
    <p class="conTitle">
      <span>반품 승인</span>
      <span class="fr"></span>
    </p>
    <span class="fr">
      <input
        type="text"
        style="width: 200px; height: 30px"
        id="sname"
        name="sname"
        v-model="searchKey"
        placeholder="제품명"
      />
      <!-- <input type="date" style="width: 120px" id="from_date" name="from_date">                         
      <input type="date" style="width: 120px" id="to_date" name="to_date"> -->

      <a class="btn btn-primary mx-2" id="btnSearch" name="btn" @click="list()"
        ><span>검색</span></a
      >
    </span>
    <br />
    <div id="refundConfirm">
      <table class="col">
        <caption>
          caption
        </caption>
        <colgroup>
          <col width="20%" />
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
          <col width="15%" />
        </colgroup>

        <thead>
          <tr>
            <th scope="col">반품고객</th>
            <th scope="col">제품명</th>
            <th scope="col">구매일자</th>
            <th scope="col">반품일자</th>
            <th scope="col">수량</th>
            <th scope="col">금액</th>
            <th scope="col">반품 승인</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in items" :key="item.RE_CODE">
            <td>{{ item.name }}</td>
            <td>{{ item.pd_NAME }}</td>
            <td>{{ item.jord_DATE }}</td>
            <td>{{ item.re_DATE }}</td>
            <td>{{ item.re_AMT }}</td>
            <td>{{ item.re_PRICE }}</td>
            <td v-if="item.re_TYPE == '0'">
              <a
                @click="sclick(item.re_CODE, '1')"
                class="btn btn-primary mx-2"
                id="btnSclick"
                name="btn"
                ><span>승인</span></a
              >
              <a
                @click="sclick(item.re_CODE, '2')"
                class="btn btn-danger mx-2"
                id="btnSclick"
                name="btn"
                ><span>반려</span></a
              >
            </td>
            <td
              v-else-if="item.re_TYPE == '1'"
              style="color: blue; font-weight: bold"
            >
              승인
            </td>
            <td
              v-else-if="item.re_TYPE == '2'"
              style="color: red; font-weight: bold"
            >
              반려
            </td>
            <td v-else></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div id="refundConfirmMgtPagination">
      <paginate
        class="justify-content-center"
        v-model="currentPage"
        :page-count="totalPage"
        :page-range="10"
        :margin-pages="0"
        :click-handler="list"
        :prev-text="'Prev'"
        :next-text="'Next'"
        :container-class="'pagination'"
        :page-class="'page-item'"
      >
      </paginate>
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next';

export default {
  data: function () {
    return {
      items: [],
      currentPage: 1,
      pageSize: 5,
      totalPage: 1,
      totalCnt: 0,
      re_type: '',
      searchKey: '',
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.list();
  },
  methods: {
    list: function () {
      let vm = this;

      let params = new URLSearchParams();

      params.append('clickpagenum', this.currentPage);
      params.append('pagesize', this.pageSize);
      params.append('searchvalue', this.searchKey);

      this.axios
        .post('/cmp/refundConfirmMgt.do', params)
        .then(function (response) {
          vm.items = response.data.refundConfirmlist;
          vm.totalCnt = response.data.refundConfirmMgtcnt;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    sclick: function (reCD, type) {
      let vm = this;
      let params = new URLSearchParams();

      params.append('re_TYPE', type);
      params.append('re_code', reCD);

      this.axios
        .post('/cmp/SclickRefundConfirm.do', params)
        .then(function (response) {
          console.log('callback : ' + JSON.stringify(response));
          vm.re_type = type;

          if (vm.re_type == 1) {
            vm.$swal.fire({
              icon: 'success',
              title: '승인 완료',
              showConfirmButton: false,
              timer: 1500,
            });
            vm.list();
          } else if (vm.re_type == 2) {
            vm.$swal.fire({
              icon: 'error',
              title: '승인 반려',
            });
            vm.list();
          }
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
  },
};
</script>
<style>
#searchArea {
  margin-top: 25px;
  margin-bottom: 25px;
}
#searchArea > * {
  height: auto;
}

#groupTitle {
  text-decoration: underline;
  font-weight: bold;
  cursor: pointer;
}
</style>
