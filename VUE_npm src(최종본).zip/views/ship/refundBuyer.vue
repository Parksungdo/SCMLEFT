<template>
  <p class="Location">
    <a class="btn_set home">메인으로</a>
    <a class="btn_nav">기업고객</a>
    <span class="btn_nav bold">반품 지시서</span>
  </p>

  <p class="conTitle">
    <span>반품 지시서</span> <span class="fr"> </span>

    <label style="margin-left: 45%">업체명 </label>
    <input
      type="text"
      style="height: 35%; width: 25%; margin-left: 1%"
      id="sname"
      v-model="simple.sname"
    />

    <a
      class="btn btn-primary mx-2"
      id="searchBtn"
      name="btn"
      style="margin-left: 2%"
      @click="list()"
      ><span>검색</span></a
    >
  </p>
  <div class="divComGrpCodList">
    <table class="col">
      <caption>
        caption
      </caption>
      <colgroup>
        <col width="5%" />
        <col width="20%" />
        <col width="20%" />
      </colgroup>

      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">업체명</th>
          <th scope="col">총액</th>
        </tr>
      </thead>
      <tbody>
        <tr
          id="listInf"
          v-for="list in simple.refundlist"
          :key="list.dir_code"
          @click="
            detailbefore(
              list.re_code,
              list.loginID,
              list.re_amt,
              list.wh_code,
              list.model_code
            )
          "
        >
          <td>{{ list.dir_code }}</td>
          <td>{{ list.company }}</td>
          <td>{{ list.sum }}</td>
        </tr>
        <tr v-if="simple.refundlist.length == 0">
          <td colspan="4">반품지시서 내역이 없습니다.</td>
        </tr>
      </tbody>
    </table>
  </div>

  <paginate
    class="justify-content-center"
    v-model="simple.currentPage"
    :page-count="simple.totalPage"
    :page-range="10"
    :margin-pages="0"
    :click-handler="list"
    :prev-text="'Prev'"
    :next-text="'Next'"
    :container-class="'pagination'"
    :page-class="'page-item'"
  >
  </paginate>

  <br /><br />
  <p class="conTitle"><span>상세 내역</span> <span class="fr"> </span></p>
  <div class="divComGrpCodList" v-show="detailflag">
    <table class="col">
      <caption>
        caption
      </caption>
      <colgroup>
        <col width="3%" />
        <col width="8%" />
        <col width="8%" />
        <col width="10%" />
        <col width="10%" />
        <col width="10%" />
        <col width="10%" />
        <col width="10%" />
      </colgroup>

      <thead>
        <tr>
          <th scope="col">반품번호</th>
          <th scope="col">장비번호</th>
          <th scope="col">장비구분</th>
          <th scope="col">모델번호</th>
          <th scope="col">모델명</th>
          <th scope="col">제조사</th>
          <th scope="col">수량</th>
          <th scope="col">판매가격</th>
        </tr>
      </thead>
      <tbody>
        <tr id="listInf" v-for="list in detail.detaillist" :key="list.dir_code">
          <td>{{ list.re_code }}</td>
          <td>{{ list.model_code }}</td>
          <td>{{ list.model_name }}</td>
          <td>{{ list.pd_code }}</td>
          <td>{{ list.pd_name }}</td>
          <td>{{ list.pdcorp }}</td>
          <td>{{ list.re_amt }}</td>
          <td>{{ list.pd_price }}</td>
        </tr>
      </tbody>
    </table>

    <paginate
      class="justify-content-center"
      v-model="detail.currentPage"
      :page-count="detail.totalPage"
      :page-range="10"
      :margin-pages="0"
      :click-handler="detailrefund"
      :prev-text="'Prev'"
      :next-text="'Next'"
      :container-class="'pagination'"
      :page-class="'page-item'"
    >
    </paginate>

    <div style="float: right">
      <a id="refundBtn" name="btn" class="btn btn-primary mx-2" @click="update"
        ><span>재고 처리</span></a
      >
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next';
//import userModal from './UserModal.vue';

export default {
  data: function () {
    return {
      simple: {
        refundlist: [],
        currentPage: 1,
        pageSize: 10,
        totalCnt: 0,
        totalPage: 1,
        sname: '',
      },
      detail: {
        detaillist: [],
        currentPage: 1,
        pageSize: 10,
        totalCnt: 0,
        totalPage: 1,
        wh_code: '',
        model_code: '',
        loginID: '',
        wh_amt: '',
        re_code: '',
      },
      detailflag: false,
    };
  },
  mounted() {
    this.list();
  },
  components: {
    paginate: Paginate,
  },
  methods: {
    list: function () {
      let vm = this;
      let params = new URLSearchParams();

      params.append('currentPage', this.simple.currentPage);
      params.append('pageSize', this.simple.pageSize);
      params.append('sname', this.simple.sname);

      this.axios
        .post('/ship/refundList.do', params)
        .then(function (response) {
          console.log(response.data);
          console.log(JSON.stringify(response));
          vm.simple.refundlist = response.data.listrefund;
          vm.simple.totalCnt = response.data.totalCount;
          vm.simple.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    detailbefore: function (re_code, loginID, re_amt, wh_code, model_code) {
      this.detail.wh_code = wh_code;
      this.detail.model_code = model_code;
      this.detail.loginID = loginID;
      this.detail.wh_amt = re_amt;
      this.detail.re_code = re_code;

      //console.log('this.detail.wh_code : ' + this.detail.wh_code,' detail.model_code : '
      //+ this.detail.model_code,' this.detail.loginID : ' + this.detail.loginID,' this.detail.wh_amt : ' + this.detail.wh_amt,' re_code : ' + re_code);

      this.detailrefund(re_code);
    },
    detailrefund: function (reCD) {
      if (this.detailflag == false) {
        this.detailflag = true;
      } else {
        this.detailflag = false;
      }
      let vm = this;
      let params = new URLSearchParams();

      params.append('currentPage', this.detail.currentPage);
      params.append('pageSize', this.detail.pageSize);
      params.append('re_code', reCD);

      this.axios
        .post('/ship/refundDtlList.do', params)
        .then(function (response) {
          console.log(response.data);
          //console.log(JSON.stringify(response));
          vm.detail.detaillist = response.data.listrefund;
          vm.detail.totalCnt = response.data.totalCount;
          vm.detail.totalPage = vm.pagedetail();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    update: function () {
      let vm = this;
      let params = new URLSearchParams();

      //console.log('this.detail.wh_code : ' + this.detail.wh_code,' detail.model_code : ' + this.detail.model_code,' this.detail.loginID : ' + this.detail.loginID,' this.detail.wh_amt : ' + this.detail.wh_amt,' re_code : ' + this.detail.re_code);

      params.append('wh_code', this.detail.wh_code);
      params.append('model_code', this.detail.model_code);
      params.append('loginID', this.detail.loginID);
      params.append('re_amt', this.detail.wh_amt);
      params.append('re_code', this.detail.re_code);

      this.$swal
        .fire({
          title: '재고처리 하시겠습니까?',
          showDenyButton: true,
          confirmButtonText: '예',
          denyButtonText: `아니오`,
        })
        .then((result) => {
          if (result.isConfirmed) {
            this.axios
              .post('/ship/refundUpdate.do', params)
              .then(function (response) {
                let msg = response.data.result;

                if (msg == 'SUCEESS') {
                  vm.$swal.fire('재고 처리 완료!', '', 'success');
                } else {
                  vm.$swal.fire('재고 처리 실패....', '', 'error');
                }
                vm.detail.detaillist = [];
                vm.detail.totalCnt = 0;
                vm.detail.totalPage = vm.pagedetail();
                vm.list();
              })
              .catch(function (error) {
                alert('에러! API 요청에 오류가 있습니다. ' + error);
              });
          }
        });
    },
    page: function () {
      var total = this.simple.totalCnt;
      var page = this.simple.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
    pagedetail: function () {
      var total = this.detail.totalCnt;
      var page = this.detail.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
  },
};
</script>
