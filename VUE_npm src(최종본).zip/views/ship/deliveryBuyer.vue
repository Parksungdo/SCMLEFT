<template>
  <div id="orderReturn">
    <div class="content">
      <p class="Location">
        <a href="#" class="btn_set home">메인으로</a>
        <a href="#" class="btn_nav">기업고객</a>
        <span class="btn_nav bold">배송 지시서</span>
        <a onClick="../system/comnCodMgr.vue" class="btn_set refresh"
          >새로고침</a
        >
      </p>

      <p class="conTitle" id="searcharea">
        <span>배송 지시서</span>
        <span class="fr">
          <input
            type="checkbox"
            v-model="deliveryDoneCheck"
            true-value="true"
            false-value=""
            v-on:change="searchDeliveryBuyerList()"
          />
          미완료 배송 목록 조회
        </span>
      </p>
      <table class="col">
        <colgroup>
          <col width="5%" />
          <col width="8%" />
          <col width="8%" />
          <col width="5%" />
          <col width="6%" />
          <col width="6%" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">주문번호</th>
            <th scope="col">주문고객</th>
            <th scope="col">배송희망일</th>
            <th scope="col">배송 담당자</th>
            <th scope="col">출발 창고지</th>
            <th scope="col">배송상태</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in deliveryBuyerList"
            :key="item.loginId"
            v-on:click="deliveryModalOpen(item.dir_code)"
          >
            <td>{{ item.jord_code }}</td>
            <td>{{ item.company }}</td>
            <td>{{ item.jord_wishdate }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.wh_name }}</td>
            <td
              v-if="item.sh_type == '배송완료'"
              style="color: skyblue; font-weight: bold"
            >
              {{ item.sh_type }}
            </td>
            <td
              v-if="item.sh_type == '배송중'"
              style="color: green; font-weight: bold"
            >
              {{ item.sh_type }}
            </td>
            <td
              v-if="item.sh_type == '배송대기'"
              style="color: red; font-weight: bold"
            >
              {{ item.sh_type }}
            </td>
          </tr>

          <tr v-if="deliveryBuyerList.length == 0">
            <td colspan="6">검색된 데이터가 없습니다.</td>
          </tr>
        </tbody>
      </table>

      <div id="comnGrpCodPagination">
        <paginate
          class="justify-content-center"
          v-model="currentPage"
          :page-count="totalPage"
          :page-range="5"
          :margin-pages="0"
          :click-handler="searchDeliveryBuyerList"
          :prev-text="'Prev'"
          :next-text="'Next'"
          :container-class="'pagination'"
          :page-class="'page-item'"
        >
        </paginate>
      </div>
    </div>
  </div>
</template>
<script>
import deliveryBuyerModal from '@/components/ship/deliveryBuyerModal.vue';
import { openModal } from 'jenesius-vue-modal';
import Paginate from 'vuejs-paginate-next'; // 페이징 처리

export default {
  data: function () {
    return {
      deliveryBuyerList: [],
      deliveryDoneCheck: '', // checked == true
      currentPage: 1, //  현재 페이지
      listCount: 10, // 리스트 뿌릴 사이즈
      totalPage: 1, // 페이징
      totalCnt: 0, // 리스트의 총 사이즈
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    /* Vue에서는 el방식이 안먹혀서 mounted에서 search 호출해서 리스트를 뿌려줘야 한다. */
    this.searchDeliveryBuyerList();
  },
  methods: {
    // 리스트 불러오기
    searchDeliveryBuyerList: function () {
      console.log('searchDeliveryBuyerList');

      let vm = this;
      let params = new URLSearchParams();

      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.listCount);
      params.append('deliveryDoneCheck', this.deliveryDoneCheck);

      this.axios
        .post('/ship/deliveryBuyerList_vue', params)
        .then(function (response) {
          console.log(response.data);

          vm.deliveryBuyerList = response.data.deliveryBuyerList;
          vm.totalCnt = response.data.totalCnt;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    deliveryModalOpen: async function (dirCode) {
      console.log('deliveryModalOpen');

      const modal = await openModal(deliveryBuyerModal, {
        title: '배송지시서 상세보기',
        code: dirCode,
      });

      modal.onclose = (popupparam) => {
        console.log('Close : ' + popupparam);
        this.searchDeliveryBuyerList(); // 모달이 닫히면서 다시 리스트 뽑아오기
      };
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.listCount;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
  },
};
</script>
