<template>
  <div id="input5">
    <p class="conTitle" style="margin-bottom: 1%">
      <span>7. watch </span>
      <span class="fr"> VueJS 변수 감시 </span>
    </p>
    <table width="100%" class="col" border="0">
      <colgroup>
        <col width="100%" />
      </colgroup>
      <tbody>
        <tr>
          <td style="text-align: left">
            1. Watch 사용 문법 확인<br />
            2. 변수 변경 이벤트 발생 후 처리
          </td>
        </tr>
      </tbody>
    </table>
    <p>
      yes/no 질문을 물어보세요:
      <input v-model="question" />
    </p>
    <p>{{ answer }}</p>
    <div><img :src="img" /></div>
  </div>
</template>

<script>
import axios from "axios";
const _ = require("lodash");
export default {
  data: function () {
    return {
      question: "",
      answer: "질문을 하기 전까지는 대답할 수 없습니다.",
      img: "",
    };
  },

  watch: {
    // 질문이 변경될 때 마다 이 기능이 실행됩니다.
    question: function () {
      this.answer = "입력을 기다리는 중...";
      this.debouncedGetAnswer();
    },
  },
  created: function () {
    // _.debounce는 lodash가 제공하는 기능으로

    // 특히 시간이 많이 소요되는 작업을 실행할 수 있는 빈도를 제한합니다.
    // 이 경우, 우리는 yesno.wtf/api 에 액세스 하는 빈도를 제한하고,
    // 사용자가 ajax요청을 하기 전에 타이핑을 완전히 마칠 때까지 기다리길 바랍니다.
    // _.debounce 함수(또는 이와 유사한 _.throttle)에 대한
    // 자세한 내용을 보려면 https://lodash.com/docs#debounce 를 방문하세요.
    this.debouncedGetAnswer = _.debounce(this.getAnswer, 500);
  },
  methods: {
    getAnswer: function () {
      if (this.question.indexOf("?") === -1) {
        this.answer = "질문에는 일반적으로 물음표가 포함 됩니다. ;-)";
        return;
      }
      this.answer = "생각중...";
      var vm = this;
      axios
        .get("https://yesno.wtf/api")
        .then(function (response) {
          vm.answer = _.capitalize(response.data.answer);
          vm.img = response.data.image;
        })
        .catch(function (error) {
          vm.answer = "에러! API 요청에 오류가 있습니다. " + error;
        });
    },
  },
};
// 태원 작업!!
</script>
