<template>
  <div class="home">회원 가입</div>
</template>
