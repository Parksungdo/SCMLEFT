<template>
  <div id="wrap_area">
    <h2 class="hidden">컨텐츠 영역</h2>
    <div id="container">
      <ul>
        <li class="contents">
          <!-- contents -->
          <h3 class="hidden">contents 영역</h3>
          <!-- content -->
          <div class="content">
            <p class="Location">
              <a href="/dashboard/dashboard.do" class="btn_set home"
                >메인으로</a
              >
              <a href="#" class="btn_nav">메인</a>
              <span class="btn_nav bold">반품현황</span>
              <a
                onClick="top.location='javascript:location.reload()'"
                class="btn_set refresh"
                >새로고침</a
              >
            </p>

            <p class="conTitle">
              <span>반품현황 </span>
            </p>

            <div id="refundtList">
              <table class="col">
                <caption>
                  caption
                </caption>

                <thead>
                  <tr>
                    <th scope="col">반품번호</th>
                    <th scope="col">주문번호</th>
                    <th scope="col">제품명</th>
                    <th scope="col">반품완료일자</th>
                    <th scope="col">반품상태</th>
                  </tr>
                </thead>
                <!--기존 자바스크립트 방법  <tbody id="productList"></tbody> -->
                <tbody>
                  <tr
                    v-for="item in listitem"
                    :key="item.reCode"
                    @click="openpop(item.reCode)"
                  >
                    <td>{{ item.reCode }}</td>
                    <td>
                      <a>{{ item.jordCode }}</a>
                    </td>
                    <td>{{ item.pdName }}</td>
                    <td>{{ item.reDate }}</td>
                    <td>{{ item.reType }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div id="refundPagination">
              <paginate
                class="justify-content-center"
                v-model="currentPage"
                :page-count="totalPage"
                :page-range="5"
                :margin-pages="0"
                :click-handler="listsearch"
                :prev-text="'Prev'"
                :next-text="'Next'"
                :container-class="'pagination'"
                :page-class="'page-item'"
              >
              </paginate>
            </div>
          </div>
          <!--// content -->
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next';
import { openModal } from 'jenesius-vue-modal';
import refundHistoryModal from './refundHistoryModal.vue';

export default {
  data: function () {
    return {
      listitem: [], // 변수선언 ex.<tbody v-for="(item, index) in SupplierListItem" v-if="SupplierListItem.length">
      action: '',
      currentPage: 1,
      pageSize: 5,
      totalPage: 1,
      totalCnt: 0,
      //search: '',
      select: 'all',
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.listsearch();
  },
  methods: {
    listsearch: function () {
      let vm = this;
      //console.log('pageNum check :: ' + pageNum);

      let params = new URLSearchParams();
      //console.log(this.currentPage);
      params.append('pageNum', this.currentPage);
      // 첫페이지 (컨트롤러에서 넘겨준 값, 뷰페이지에서 사용할 값 )
      params.append('listCount', this.pageSize); // 페이지 갯수
      //params.append('search', this.search);
      params.append('select', this.select);

      this.axios
        .post('/cor/searchReturnList', params)
        .then(function (response) {
          console.log(response);
          //           vm.listitem = response.data.returnList;
          // vm.totalCnt = response.data.returnCount;
          vm.listitem = response.data.result.returnList;
          vm.totalCnt = response.data.result.returnCount;
          vm.totalPage = vm.page();

          console.log('dfdf' + vm.totalCnt);
          console.log('sdfsdf' + vm.totalPage);
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;

      console.log(this.totalCnt); // 리스트의 총수량
      console.log(this.pageSize); // 내가 리스트 뿌릴 수량

      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        console.log('sdfsdf');
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    openpop: async function (selmodelCode) {
      const modal = await openModal(refundHistoryModal, {
        ptitle: '상세보기',
        selmodelCode: selmodelCode, // =reCode
      });

      modal.onclose = () => {
        console.log('Close ');
        this.listsearch();
      };
    },
  },
};
</script>

<style>
#searchArea {
  margin-top: 25px;
  margin-bottom: 25px;
}
#searchArea > * {
  height: auto;
}

#groupTitle {
  text-decoration: underline;
  font-weight: bold;
  cursor: pointer;
}
</style>
