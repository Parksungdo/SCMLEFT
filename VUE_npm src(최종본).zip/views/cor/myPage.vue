<template>
  <form id="myUser">
    <div id="wrap_area">
      <h2 class="hidden">컨텐츠 영역</h2>
      <div id="container">
        <ul>
          <div class="content">
            <p class="Location">
              <a href="../dashboard/dashboard.do" class="btn_set home"
                >메인으로</a
              >
              <span class="btn_nav bold">마이페이지</span>
              <span class="btn_nav bold">정보 변경</span>
              <a href="../cor/myPage" class="btn_set refresh">새로고침</a>
            </p>

            <p class="conTitle">
              <span>마이 페이지 </span>
            </p>

            <div id="userinfoarea">
              <input type="hidden" id="loginID" name="loginID" />
              <!-- 수정시 필요한 num 값을 넘김  -->
              <dl>
                <dd class="content">
                  <table class="row">
                    <caption>
                      caption
                    </caption>
                    <colgroup>
                      <col width="120px" />
                      <col width="*" />
                      <col width="120px" />
                      <col width="*" />
                    </colgroup>

                    <tbody>
                      <tr>
                        <th scope="row" style="width: 70px">
                          아이디 <span class="font_red">*</span>
                        </th>
                        <td>
                          <input
                            type="text"
                            name="rloginID"
                            id="rloginID"
                            v-model="rloginID"
                            readonly="readonly"
                          />
                        </td>

                        <th style="width: 70px" scope="row">
                          비밀번호<span class="font_red">*</span>
                        </th>
                        <td>
                          <input
                            type="password"
                            name="password"
                            id="password"
                            v-model="password"
                          />
                        </td>
                      </tr>

                      <tr>
                        <th scope="row">
                          연락처 <span class="font_red">*</span>
                        </th>
                        <td>
                          <input
                            style="width: 160px"
                            type="text"
                            id="hp"
                            name="hp"
                            v-model="hp"
                          />
                        </td>
                        <th style="width: 70px" scope="row">
                          비밀번호 확인<span class="font_red">*</span>
                        </th>
                        <td>
                          <input
                            type="password"
                            name="repassword"
                            id="repassword"
                            v-model="repassword"
                          />
                        </td>
                      </tr>

                      <tr>
                        <th scope="row" style="width: 70px">
                          이름<span class="font_red">*</span>
                        </th>
                        <td>
                          <input
                            type="text"
                            name="name"
                            id="name"
                            v-model="name"
                          />
                        </td>

                        <th scope="row">이메일</th>
                        <td style="width: 30%">
                          <input
                            type="text"
                            name="email"
                            id="email"
                            v-model="email"
                            size="30"
                          />
                        </td>
                      </tr>

                      <tr id="outstaff">
                        <th scope="row" style="width: 70px">
                          회사명<span class="font_red">*</span>
                        </th>
                        <td colspan="4">
                          <input
                            type="text"
                            name="company"
                            id="company"
                            v-model="company"
                          />
                        </td>
                      </tr>

                      <tr>
                        <th style="width: 70px" scope="row">
                          우편번호<span class="font_red">*</span>
                        </th>
                        <td colspan="4">
                          <input
                            type="text"
                            name="zip"
                            id="zip"
                            v-model="zip"
                          />
                          <input
                            type="button"
                            value="우편번호 찾기"
                            @click="post()"
                            style="width: 130px; height: 20px"
                          />
                        </td>
                      </tr>
                      <tr>
                        <th style="width: 70px" scope="row">
                          주소<span class="font_red">*</span>
                        </th>
                        <td colspan="4">
                          <input
                            type="text"
                            name="addr"
                            id="addr"
                            v-model="addr"
                            size="100"
                          />
                        </td>
                      </tr>
                      <tr>
                        <th style="width: 70px" scope="row">
                          상세주소<span class="font_red">*</span>
                        </th>
                        <td colspan="4">
                          <input
                            type="text"
                            name="dtl_add"
                            id="dtl_add"
                            v-model="dtl_add"
                            size="100"
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="btn_areaC mt30">
                    <a
                      @click="passchk()"
                      class="btn btn-primary mx-2"
                      id="btnUpdateUser"
                      name="btn"
                      ><span>정보 수정</span></a
                    >
                  </div>
                </dd>
              </dl>
              <!-- <a href="" class="closePop"><span class="hidden">닫기</span></a> -->
            </div>
          </div>
        </ul>
      </div>
    </div>
  </form>
</template>

<script>
//import { response } from 'express';

export default {
  data: function () {
    return {
      rloginID: '',
      name: '',
      password: '',
      repassword: '',
      hp: '',
      email: '',
      zip: '',
      addr: '',
      dtl_add: '',
      company: '',
    };
  },
  mounted: function () {
    let vm = this;

    this.axios
      .post('/cor/detailUser.do')
      .then(function (response) {
        console.log(response);

        vm.rloginID = response.data.result.loginID;
        vm.name = response.data.result.name;
        vm.password = response.data.result.password;
        vm.repassword = response.data.result.password;
        vm.hp = response.data.result.hp;
        vm.email = response.data.result.email;
        vm.zip = response.data.result.zip;
        vm.addr = response.data.result.addr;
        vm.dtl_add = response.data.result.dtl_add;
        vm.company = response.data.result.company;
      })
      .catch(function (error) {
        alert('불러오기 실패' + error);
      });
  },
  methods: {
    post() {
      new window.daum.Postcode({
        oncomplete: (data) => {
          // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

          // 도로명 주소의 노출 규칙에 따라 주소를 조합한다.
          // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
          let fullRoadAddr = data.roadAddress; // 도로명 주소 변수
          let extraRoadAddr = ''; // 도로명 조합형 주소 변수

          // 법정동명이 있을 경우 추가한다. (법정리는 제외)
          // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
            extraRoadAddr += data.bname;
          }
          // 건물명이 있고, 공동주택일 경우 추가한다.
          if (data.buildingName !== '' && data.apartment === 'Y') {
            extraRoadAddr +=
              extraRoadAddr !== ''
                ? ', ' + data.buildingName
                : data.buildingName;
          }
          // 도로명, 지번 조합형 주소가 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
          if (extraRoadAddr !== '') {
            extraRoadAddr = ' (' + extraRoadAddr + ')';
          }
          // 도로명, 지번 주소의 유무에 따라 해당 조합형 주소를 추가한다.
          if (fullRoadAddr !== '') {
            fullRoadAddr += extraRoadAddr;
          }
          // 우편번호와 주소 정보를 해당 필드에 넣는다.
          this.zip = data.zonecode; //5자리 새우편번호 사용
          this.addr = fullRoadAddr;
          document.getElementById('dtl_add').focus();
        },
      }).open();
    },

    passchk: function () {
      let pwd = this.password;
      let repwd = this.repassword;
      let email = this.email;
      let hp = this.hp;
      let zip = this.zip;
      let addr = this.addr;
      let dtl_add = this.dtl_add;
      let name = this.name;
      let company = this.company;

      // let passwordRules =
      //   /^.*(?=^.{8,15}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/;
      let emailRules =
        /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;

      if (pwd == null || pwd == '') {
        alert('비번을 입력하세요');
      } else if (email == null || email == '') {
        alert('이메일 입력하세요');
      } else if (hp == null || hp == '') {
        alert('연락처 입력하세요');
      } else if (zip == null || zip == '') {
        alert('우편번호 입력하세요');
      } else if (addr == null || addr == '') {
        alert('주소 입력하세요');
      } else if (dtl_add == null || dtl_add == '') {
        alert('상세주소 입력하세요');
      } else if (company == null || company == '') {
        alert('회사명 입력하세요');
      } else if (name == null || name == '') {
        alert('이름 입력하세요');
      } else if (pwd != repwd) {
        alert('비밀 번호가 서로 일치하지 않습니다.');
      } else if (!emailRules.test(email)) {
        alert('이메일 형식을 확인해주세요.');
      } else {
        this.save();
      }
    },

    save: function () {
      let vm = this;
      let params = new FormData(document.getElementById('myUser'));
      params.append('rloginID', this.rloginID);

      this.axios({
        url: '/cor/saveUser.do',
        method: 'POST',
        data: params,
      })
        .then(function (response) {
          console.log(response);
          vm.$swal('수정완료');
        })
        .catch(function (error) {
          alert('저장 에러!' + error);
        });
    },
  },
};
</script>
