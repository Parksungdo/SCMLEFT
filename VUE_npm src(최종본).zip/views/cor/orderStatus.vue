<template>
  <form id="myForm" action="" method="">
    <input type="hidden" id="currentPage" value="" />
    <input type="hidden" id="currentPageModal" value="" />
    <!-- 모달 배경 -->
    <div id="mask"></div>
    <div id="wrap_area">
      <h2 class="hidden">컨텐츠 영역</h2>
      <div id="container">
        <ul>
          <li class="contents">
            <!-- contents -->
            <h3 class="hidden">contents 영역</h3>
            <!-- content -->

            <!-- 타이틀 영역 -->
            <div class="content" style="margin-bottom: 20px">
              <p class="Location">
                <a href="../dashboard/dashboard.do" class="btn_set home"
                  >메인으로</a
                >
                <span class="btn_nav bold">메인</span>
                <span class="btn_nav bold">현황</span>
                <span class="btn_nav bold">주문현황 및 반품신청</span>
                <a href="../cor/myPage" class="btn_set refresh">새로고침</a>
              </p>
              <div>
                <p class="conTitle" style="margin-bottom: 1%">
                  <span>주문현황</span>
                  <span class="fr">
                    <span>구매일자</span>
                    <input type="date" id="inpStartDate" />
                    <span> ~ </span>
                    <input type="date" id="inpEndDate"
                  /></span>
                </p>
              </div>

              <!-- 주문상태 -->
              <div style="height: 15rem; margin-bottom: 3rem">
                <table class="col">
                  <thead>
                    <tr>
                      <th scope="col">주문번호</th>
                      <th scope="col">제품명</th>
                      <th scope="col">금액</th>
                      <th scope="col">구매일</th>
                      <th scope="col">배송일</th>
                      <th scope="col">입금상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr
                      v-for="item in listitem"
                      :key="item.jordNo"
                      @click="getlistdeteil(item.jordNo)"
                    >
                      <td>{{ item.jordNo }}</td>
                      <td>{{ item.pdName }}</td>
                      <td>{{ item.total }}</td>
                      <td>{{ item.jordDate }}</td>
                      <td>{{ item.shDate }}</td>
                      <td>
                        <templete v-if="item.jordIn == '1'">
                          <div style="color: skyblue; font-weight: bold">
                            입금
                          </div>
                        </templete>
                        <templete v-else>
                          <a
                            class="btn btn-primary mx-2"
                            v-on:Click="updJordIn(item.jordNo)"
                            ><span>입금하기</span></a
                          >
                        </templete>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div id="comnGrpCodPagination">
                  <paginate
                    class="justify-content-center"
                    v-model="pageNum"
                    :page-count="totalPage"
                    :page-range="5"
                    :margin-pages="0"
                    :click-handler="getList"
                    :prev-text="'Prev'"
                    :next-text="'Next'"
                    :container-class="'pagination'"
                    :page-class="'page-item'"
                  >
                  </paginate>
                </div>
              </div>

              <div style="height: 15rem; margin-bottom: 3rem">
                <table class="col">
                  <thead>
                    <tr>
                      <th scope="col">선택</th>
                      <th scope="col">주문번호</th>
                      <th scope="col">제품명</th>
                      <th scope="col">제품번호</th>
                      <th scope="col">제조사</th>
                      <th scope="col">단가</th>
                      <th scope="col">수량</th>
                      <th scope="col">합계금액</th>
                      <th scope="col">상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-if="totalCnt1 == 0">
                      <td colspan="9">제품을 선택하세요</td>
                    </tr>
                    <tr
                      v-for="item in listitem1"
                      :key="item.jordNo"
                      v-show="orderflag"
                    >
                      <td><input type="checkBox" name="cheReturn" /></td>
                      <td>{{ item.jordNo }}</td>
                      <td>{{ item.pdName }}</td>
                      <td>{{ item.pdCode }}</td>
                      <td>{{ item.pdCorp }}</td>
                      <td>{{ item.pdPrice }}</td>
                      <td>{{ item.jordAmt }}</td>
                      <td>{{ item.total }}</td>
                      <td
                        v-if="item.reCode == 0"
                        style="color: blue; font-weight: bold"
                      >
                        반품가능
                      </td>
                      <td
                        v-if="item.reCode != 0"
                        style="color: red; font-weight: bold"
                      >
                        반품신청완료
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div id="comnGrpCodPagination1">
                  <paginate
                    class="justify-content-center"
                    v-model="pageNum1"
                    :page-count="totalPage1"
                    :page-range="5"
                    :margin-pages="0"
                    :click-handler="getlistdeteil"
                    :prev-text="'Prev'"
                    :next-text="'Next'"
                    :container-class="'pagination'"
                    :page-class="'page-item'"
                  >
                  </paginate>
                </div>
                <a
                  class="btn btn-danger mx-2"
                  name="btn"
                  v-show="!returnCheck"
                  v-on:click="insReturnInfo()"
                  style="float: right"
                  ><span>반품하기</span></a
                >
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </form>
</template>

<script>
import Paginate from 'vuejs-paginate-next';

export default {
  data: function () {
    return {
      listitem: [],
      pageNum: 1,
      listCount: 5,
      totalPage: 1,
      totalCnt: 0,

      jordNo: '',
      listitem1: [],
      pageNum1: 1,
      listCount1: 5,
      totalPage1: 1,
      totalCnt1: 0,

      returnCheck: true,
      orderflag: false,
    };
  },
  components: {
    paginate: Paginate,
  },
  mounted() {
    this.getList();
  },

  methods: {
    getList: function () {
      this.orderflag = false;

      let vm = this;

      let params = new URLSearchParams();
      params.append('pageNum', this.pageNum);
      params.append('listCount', this.listCount);

      this.axios.post('/cor/searchOrderList', params).then(function (response) {
        console.log(JSON.stringify(response));
        vm.listitem = response.data.newOrder;
        vm.totalCnt = response.data.orderCount;
        vm.totalPage = vm.page();
      });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.listCount;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    getlistdeteil: function (jordNo) {
      console.log(jordNo);
      this.jordNo = jordNo;
      this.orderflag = true;

      let vm = this;
      let params = new URLSearchParams();

      params.append('pageNum', this.pageNum1);
      params.append('listCount', this.listCount1);
      params.append('jordNo', this.jordNo);

      this.axios.post('/cor/refundHistory', params).then(function (response) {
        console.log(response);
        vm.listitem1 = response.data.osdList;
        vm.totalCnt1 = response.data.detailCount;
        vm.totalPage1 = vm.page1();

        if (vm.listitem1.length == 0) vm.returnCheck = true;
        else vm.returnCheck = false;
      });
    },
    // 입금하기
    updJordIn: function (no) {
      console.log('updJordIn');

      const vm = this;
      let params = new URLSearchParams();

      params.append('pageNum', this.pageNum);
      params.append('listCount', this.listCount);
      params.append('jordNo', no);
      params.append('jordIn', '1');

      this.axios.post('/cor/updJorderStatus', params).then(function (response) {
        console.log(response.data);

        vm.$swal(response.data.message);
        vm.listitem = response.data.newOsList;
        vm.totalCnt = response.data.orderCount;
        vm.totalPage = vm.page();
      });
    },
    // 반품하기
    insReturnInfo: function () {
      console.log('insReturnInfo');

      const vm = this;
      let params = new URLSearchParams();

      let i = -1;
      let jordCode = '';
      let modelCode = '';
      let whCode = '';
      let bordCode = '';
      let jordAmt = '';
      let cheReturn = document.getElementsByName('cheReturn');
      let message = '주문번호 ';

      if (
        document.querySelectorAll("input[name='cheReturn']:checked").length == 0
      ) {
        return this.$swal.fire({
          icon: 'error',
          title: '반품 신청할 제품을 선택해주세요.',
        });
      }

      cheReturn.forEach((item, index) => {
        console.log('all :: ' + index);

        if (item.checked == true) {
          console.log('checked :: ' + index);

          if (this.listitem1[index].reCode == 0) {
            i++;

            console.log(i);

            console.log(this.listitem1[index].jordCode);
            console.log(this.listitem1[index].modelCode);
            console.log(this.listitem1[index].whCode);
            console.log(this.listitem1[index].bordCode);
            console.log(parseInt(this.listitem1[index].jordAmt));

            jordCode += (i != 0 ? '&' : '') + this.listitem1[index].jordCode;
            modelCode += (i != 0 ? '&' : '') + this.listitem1[index].modelCode;
            whCode += (i != 0 ? '&' : '') + this.listitem1[index].whCode;
            bordCode += (i != 0 ? '&' : '') + this.listitem1[index].bordCode;
            jordAmt +=
              (i != 0 ? '&' : '') + parseInt(this.listitem1[index].jordAmt);
          }
        } else {
          message += this.listitem1[index].jordCode + ' ';
        }
      });

      if (jordCode == '') return this.$swal('반품신청 가능한 제품이 없습니다.');
      this.$swal(message + ' 빼고 반품신청 들어갑니다.');

      params.append('pageNum', this.pageNum1);
      params.append('listCount', this.listCount1);
      params.append('jordCode', jordCode);
      params.append('jordNo', this.jordNo);
      params.append('modelCode', modelCode);
      params.append('whCode', whCode);
      params.append('bordCode', bordCode);
      params.append('reAmt', jordAmt);

      this.axios
        .post('/cor/insReturnProduct', params)
        .then(function (response) {
          console.log(response.data);

          vm.$swal(response.data.message);
          vm.listitem1 = response.data.osdList;
          vm.totalCnt1 = response.data.detailCount;
          vm.totalPage1 = vm.page1();

          cheReturn.forEach((item) => {
            item.checked = false;
          });
        });
    },
    page1: function () {
      var total1 = this.totalCnt1;
      var page1 = this.listCount1;
      var xx1 = total1 % page1;
      var result1 = parseInt(total1 / page1);

      if (xx1 == 0) {
        return result1;
      } else {
        result1 = result1 + 1;
        return result1;
      }
    },
  },
};
</script>
