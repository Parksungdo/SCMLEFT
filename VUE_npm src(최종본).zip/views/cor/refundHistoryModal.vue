<template>
  <div id="modal">
    <table class="col" width="800px">
      <caption>
        caption
      </caption>
      <colgroup>
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
        <col width="120px" />
      </colgroup>

      <tbody>
        <tr>
          <td colspan="8" class="text-center">
            <div class="my-4">
              <strong style="font-size: 30px">{{ ptitle }}</strong>
            </div>
          </td>
        </tr>
        <tr>
          <th scope="row">반품번호</th>
          <th scope="row">주문번호</th>
          <th scope="row">제품명</th>
          <th scope="row">제품CODE</th>
          <th scope="row">제품수량</th>
          <th scope="row">반품일자</th>
          <th scope="row">반품상태</th>
          <th scope="row">가격</th>
        </tr>
        <tr>
          <td>
            {{ reCode }}
          </td>
          <td>
            {{ jordCode }}
          </td>
          <td>
            {{ pdName }}
          </td>
          <td>
            {{ pdCode }}
          </td>
          <td>
            {{ reAmt }}
          </td>
          <td>
            {{ reDate }}
          </td>
          <td>
            {{ reType }}
          </td>
          <td>
            {{ total }}
          </td>
        </tr>
      </tbody>
    </table>

    <!-- e : 여기에 내용입력 -->

    <div class="btn_areaC mt30">
      <a
        @click="closepopup()"
        class="btn btn-primary mx-2"
        id="btnClose"
        name="btn"
        ><span>닫기</span></a
      >
    </div>
  </div>
</template>

<script>
import { closeModal } from 'jenesius-vue-modal';
// 1. jenesius-vue-modal 으로 인스톨
// 이미 만들어져 있는 기능 사용함 (사용법은 jenesius-vue-modal로 구글검색하면 나온다)

export default {
  // vue에서는 받아온 변수를 methods에서 직접 핸들링이 불가능하기 때문에
  // 임시 변수를 만들어서 받아온 변수를 넣어 줘야 함
  props: { ptitle: String, selmodelCode: Number },
  data: function () {
    return {
      preCode: this.selmodelCode,
      reCode: '',
      jordCode: '',
      pdName: '',
      pdCode: '',
      reAmt: '',
      reDate: '',
      reType: '',
      total: '',
    };
  },

  // html 로딩, 가상 dom 실행, 이 두 개 연결 시 작동
  mounted: function () {
    let vm = this;

    let params = new URLSearchParams();
    params.append('reCode', this.preCode);
    params.append('pageNum', 1);
    params.append('listCount', 1);
    params.append('type', 'Y');

    console.log('reCode :: ' + this.preCode);

    this.axios
      .post('/cor/getReturnDetail', params)
      .then(function (response) {
        console.log('params :: ' + params);

        //vm.title = response.data.selectresult.nottitle;
        //vm.cont = response.data.selectresult.notcon;
        vm.reCode = response.data.result.returnList[0].reCode;
        vm.jordCode = response.data.result.returnList[0].jordCode;
        vm.pdName = response.data.result.returnList[0].pdName;
        vm.pdCode = response.data.result.returnList[0].pdCode;
        vm.reAmt = response.data.result.returnList[0].reAmt;
        vm.reDate = response.data.result.returnList[0].reDate;
        vm.reType = response.data.result.returnList[0].reType;
        vm.total = response.data.result.returnList[0].total;
      })
      .catch(function (error) {
        alert('에러! API 요청에 오류가 있습니다. ' + error);
      });
  },
  methods: {
    closepopup: function () {
      closeModal();
    },
  },
};
</script>

<style>
#modal {
  background-color: #fff;
  padding: 3rem;
  border-radius: 10px;
  border: 2px solid rgb(59, 59, 59);
}
</style>
