<template>
  <div id="comnCodMgr">
    <p class="Location">
      <a href="/dashboard/home" class="btn_set home"></a>
      <span class="btn_nav bold">작업지시서</span>
      <span class="btn_nav bold">반품지시서</span>
      <a href="../system/comnCodMgr.do" class="btn_set refresh">새로고침</a>
    </p>

    <!-- 검색 영역 -->
    <div id="divSearchBar">
      <p class="conTitle" id="searcharea">
        <span>반품 지시서 목록</span>
        <span id="search" class="fr">
          <input
            class="datetype"
            type="date"
            id="sdate"
            name="sdate"
            v-model="sdate"
          />
          <input
            class="datetype"
            type="date"
            id="edate"
            name="edate"
            v-model="edate"
          />
          <input
            type="text"
            id="cpname"
            name="cpname"
            style="height: 27px"
            placeholder="기업고객명"
            v-model="cpname"
          />
          <a @click="search()" class="btn btn-primary mx-2" name="search">
            <span>검색</span>
          </a>
        </span>
      </p>
    </div>

    <!-- 발주지시서 리스트 영역 -->
    <div id="divPurchaseList">
      <table class="col">
        <colgroup>
          <col width="15%" />
          <col width="15%" />
          <col width="20%" />
          <col width="10%" />
          <col width="15%" />
          <col width="10%" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">주문일자</th>
            <th scope="col">기업고객명</th>
            <th scope="col">제품명</th>
            <th scope="col">반품 개수</th>
            <th scope="col">금액</th>
            <th scope="col">승인여부</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="totalCnt == 0">
            <tr>
              <td colspan="9">일치하는 검색 결과가 없습니다</td>
            </tr>
          </template>
          <template v-else>
            <tr v-for="item in list" :key="item.jordDate">
              <td>{{ item.jordDate }}</td>
              <td>{{ item.company }}</td>
              <td>{{ item.pdName }}</td>
              <td>{{ item.reAmt }}</td>
              <td>{{ item.returnPrice }}</td>
              <td>{{ item.reType }}</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
    <div id="purchasePagination">
      <paginate
        class="justify-content-center"
        v-model="currentPage"
        :page-count="totalPage"
        :page-range="5"
        :margin-pages="0"
        :click-handler="search"
        :prev-text="'Prev'"
        :next-text="'Next'"
        :container-class="'pagination'"
        :page-class="'page-item'"
      >
      </paginate>
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next';

export default {
  components: {
    paginate: Paginate,
  },
  data: function () {
    return {
      currentPage: 1,
      pageSize: 10,
      totalPage: 1,
      totalCnt: 0,
      cpname: '',
      sdate: '',
      edate: '',
      list: [],
    };
  },
  mounted() {
    this.search();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);
      params.append('cpname', this.cpname);
      params.append('sdate', this.sdate.replaceAll('-', ''));
      params.append('edate', this.edate.replaceAll('-', ''));

      console;

      this.axios
        .post('/scm/returnDirList.do', params)
        .then(function (response) {
          console.log(response);
          vm.list = response.data.returnDirList;
          vm.totalCnt = response.data.totalCnt;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러' + error);
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
  },
};
</script>
