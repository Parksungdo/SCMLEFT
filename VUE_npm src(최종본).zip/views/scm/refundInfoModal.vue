<template>
  <div
    id="refundDirection"
    class="layerPop layerType2"
    style="width: 1000px; display: table"
  >
    <dl>
      <dt>
        <strong>반품지시서</strong>
      </dt>
      <dd class="content">
        <table class="col" id="refundModalTable">
          <caption>
            caption
          </caption>
          <colgroup>
            <col width="8%" />
            <col width="6%" />
            <col width="8%" />
            <col width="8%" />
          </colgroup>

          <thead>
            <tr>
              <th scope="col">반품 제품명</th>
              <th scope="col">반품 완료날짜</th>
              <th scope="col">반품수량</th>
              <th scope="col">반품 금액</th>
            </tr>
          </thead>
          <tr>
            <td style="text-align: center" readonly>
              {{ model_NAME }} + {{ re_TYPE }}
            </td>
            <td style="text-align: center" readonly>{{ re_DATE }}</td>
            <td style="text-align: center" readonly>{{ re_AMT }}</td>
            <td style="text-align: center" readonly>{{ re_PRICE }}</td>
            <!-- <td style="text-align: center" readonly>{{ re_TYPE }}</td> -->
          </tr>
        </table>

        <div class="btn_areaC mt30" v-show="re_TYPE == null">
          <templete>
            <a class="btn btn-primary mx-2" @click="appr"
              ><span>승인요청</span></a
            >
          </templete>
        </div>
      </dd>
    </dl>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';
export default {
  props: { re_code: Number },
  data: function () {
    return {
      reCD: this.re_code,
      re_DATE: '',
      model_NAME: '',
      re_AMT: '',
      re_PRICE: '',
      re_TYPE: '',
      dirCD: '',
    };
  },
  // html 로딩, 가상 dom 실행, 이 두 개 연결 시 작동
  mounted: function () {
    this.detail();
  },
  methods: {
    detail: function () {
      let vm = this;
      let params = new URLSearchParams();
      params.append('re_code', this.reCD);

      this.axios
        .post('/scm/refundDtModal.do', params)
        .then(function (response) {
          //alert('save callback : ' + JSON.stringify(response));
          console.log('callback : ' + JSON.stringify(response.data));
          vm.model_NAME = response.data.result.model_NAME;
          vm.re_DATE = response.data.result.re_DATE;
          vm.re_AMT = response.data.result.re_AMT;
          vm.re_PRICE = response.data.result.re_PRICE;
          vm.re_TYPE = response.data.result.re_TYPE;
          console.log(vm.re_TYPE);
          //vm.dirCD = response.data.restult.dir_code;
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    appr: function () {
      this.$swal
        .fire({ title: '반품 승인 요청하시겠습니까?', showDenyButton: true })
        .then((result) => {
          if (result.isConfirmed) {
            let vm = this;
            let params = new URLSearchParams();
            params.append('re_code', this.reCD);
            params.append('RE_AMT', this.re_AMT);

            this.axios
              .post('/scm/updateRefund.do', params)
              .then(function (response) {
                console.log(response.data);

                vm.$swal.fire({
                  icon: 'success',
                  title: '승인 완료!',
                  showConfirmButton: false,
                  timer: 1500,
                });
                closeModal();
              })
              .catch(function (error) {
                alert('에러! API 요청에 오류가 있습니다. ' + error);
              });
          }
        });
    },
  },
};
</script>
