<template>
  <div id="comnCodMgr">
    <p class="Location">
      <router-link :to="'/dashboard/home'">
        <a class="btn_set home"></a>
      </router-link>
      <span class="btn_nav bold">기준 정보</span>
      <span class="btn_nav bold">사용자 정보 관리</span>
      <router-link :to="'/dashboard/scm/UserInfo'">
        <a class="btn_set refresh">새로고침</a>
      </router-link>
    </p>
    <p class="conTitle">
      <span>사용자 관리</span>
      <span class="fr">
        <select id="option" name="option" style="height: 27px" v-model="option">
          <option value="">전체</option>
          <option value="user_id">아이디</option>
          <option value="user_name">회사/성명</option>
          <option value="user_cha">담당업무</option>
        </select>
        <input
          type="text"
          id="search"
          name="search"
          v-model="search"
          style="height: 27px"
        />
        <a
          class="btn btn-primary mx-2"
          type="button"
          name="modal"
          value="검색"
          @click="list()"
        >
          <span>검색</span></a
        >
        <a class="btn btn-primary mx-2" name="modal" @click="detailuser()">
          <span>신규등록</span></a
        >
      </span>
    </p>

    <div id="divUserList">
      <div class="bootstrap-table">
        <div class="fixed-table-toolbar">
          <div class="bs-bars pull-left"></div>
          <div class="columns columns-right btn-group pull-right"></div>
        </div>
        <div class="fixed-table-container" style="padding-bottom: 0px">
          <div class="fixed-table-body">
            <table class="col">
              <caption>
                caption
              </caption>
              <colgroup>
                <col width="8%" />
                <col width="18%" />
                <col width="18%" />
                <col width="23%" />
                <col width="18%" />
                <col width="15%" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">아이디</th>
                  <th scope="col">회사명/성명</th>
                  <th scope="col">담당자명</th>
                  <th scope="col">담당업무</th>
                  <th scope="col">연락처</th>
                </tr>
              </thead>
              <tbody id="listInf" v-for="list in userlist" :key="list.loginID">
                <tr @click="detailuser(list.loginID, list.div_cd)">
                  <td>{{ list.divCD }}</td>
                  <td>{{ list.loginID }}</td>
                  <td>{{ list.company }}</td>
                  <td>{{ list.name }}</td>
                  <td>{{ list.chaCD }}</td>
                  <td>{{ list.hp }}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div>
            <div>
              <div class="clearfix" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <paginate
      class="justify-content-center"
      v-model="currentPage"
      :page-count="totalPage"
      :page-range="10"
      :margin-pages="0"
      :click-handler="list"
      :prev-text="'Prev'"
      :next-text="'Next'"
      :container-class="'pagination'"
      :page-class="'page-item'"
    >
    </paginate>
  </div>
</template>
<script>
import { openModal } from 'jenesius-vue-modal';
import Paginate from 'vuejs-paginate-next';
import userModal from './UserModal.vue';

export default {
  data: function () {
    return {
      userlist: [],
      currentPage: 1,
      pageSize: 10,
      totalCnt: 0,
      totalPage: 1,
      search: '',
      option: '',
      action: '',
    };
  },
  mounted() {
    this.list();
  },
  components: {
    paginate: Paginate,
  },
  methods: {
    list: function () {
      let vm = this;
      let params = new URLSearchParams();

      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);
      params.append('search', this.search);
      params.append('option', this.option);
      console.log('params : ' + params);
      this.axios
        .post('/scm/UserInfoList.do', params)
        .then(function (response) {
          console.log('callback : ' + JSON.stringify(response));
          vm.userlist = response.data.listUser;
          vm.totalCnt = response.data.totalCount;
          //vm.search = response.search;
          //vm.option = response.option;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
    detailuser: async function (loginID, div_cd) {
      if (loginID == '' || loginID == null) {
        this.action = 'I';

        const modal = await openModal(userModal, {
          ptitle: '신규 등록',
          loginID: '',
          action: this.action,
          divcd: div_cd,
        });

        modal.onclose = () => {
          console.log('Close ');
          this.list();
        };
      } else {
        this.action = 'U';

        const modal = await openModal(userModal, {
          ptitle: '사용자 정보 수정',
          loginID: loginID,
          action: this.action,
          divcd: div_cd,
        });

        modal.onclose = () => {
          console.log('Close ');
          this.list();
        };
      }
    },
  },
};
</script>
