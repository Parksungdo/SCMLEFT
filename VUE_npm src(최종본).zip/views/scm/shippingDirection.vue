<template>
  <div id="comnCodMgr">
    <p class="Location">
      <a href="/dashboard/home" class="btn_set home"></a>
      <span class="btn_nav bold">작업지시서</span>
      <span class="btn_nav bold">배송지시서</span>
      <a href="../system/comnCodMgr.do" class="btn_set refresh">새로고침</a>
    </p>

    <!-- 검색 영역 -->
    <div id="divSearchBar">
      <p class="conTitle" id="searcharea">
        <span>배송 지시서</span>
        <label style="margin-left: 67%">
          <input
            type="checkbox"
            id="shippingDoneCheck"
            v-model="shippingDoneCheck"
            v-on:change="search()"
          />
          배송 미완료 목록 조회</label
        >
      </p>
    </div>

    <!-- 발주지시서 리스트 영역 -->
    <div id="divPurchaseList">
      <table class="col">
        <colgroup>
          <col width="5%" />
          <col width="8%" />
          <col width="10%" />
          <col width="8%" />
          <col width="5%" />
          <col width="8%" />
          <col width="5%" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">주문 번호</th>
            <th scope="col">주문 제품</th>
            <th scope="col">주문 일자</th>
            <th scope="col">고객 기업</th>
            <th scope="col">주문 개수</th>
            <th scope="col">배송 희망 일자</th>
            <th scope="col">배송 상태</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in list"
            :key="item.jord_code"
            @click="showBordDirectionDetail(item.dir_code)"
          >
            <td>{{ item.jord_code }}</td>
            <td>{{ item.pd_name }}</td>
            <td>{{ item.jord_date }}</td>
            <td>{{ item.pd_corp }}</td>
            <td>{{ item.jord_amt }}</td>
            <td>{{ item.jord_wishdate }}</td>
            <td>{{ item.sh_type }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div id="purchasePagination">
      <paginate
        class="justify-content-center"
        v-model="currentPage"
        :page-count="totalPage"
        :page-range="5"
        :margin-pages="0"
        :click-handler="search"
        :prev-text="'Prev'"
        :next-text="'Next'"
        :container-class="'pagination'"
        :page-class="'page-item'"
      >
      </paginate>
    </div>
  </div>
</template>
<script>
import { openModal } from 'jenesius-vue-modal';
import Paginate from 'vuejs-paginate-next';
import shippingDirectionModal from './shippingDirectionModal.vue';

export default {
  components: {
    paginate: Paginate,
  },
  data: function () {
    return {
      currentPage: 1,
      pageSize: 5,
      totalPage: 1,
      totalCnt: 0,

      list: [],
      shippingDoneCheck: '',
    };
  },
  mounted() {
    this.search();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);

      if (this.shippingDoneCheck == ':checked') {
        this.shippingDoneCheck = 'refund';
      } else if (this.shippingDoneCheck == '') {
        this.shippingDoneCheck = '';
      }

      params.append('shippingDoneCheck', this.shippingDoneCheck);

      this.axios
        .post('/scm/shippingDirectionListVue.do', params)
        .then(function (response) {
          console.log(response.data);
          vm.list = response.data.shippingDirectionList;
          vm.totalCnt = response.data.totalCnt;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러' + error);
        });
    },

    page: function () {
      var total = this.totalCnt;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    showBordDirectionDetail: async function (dir_code) {
      if (dir_code != '' || dir_code != null) {
        const modal = await openModal(shippingDirectionModal, {
          dir_code: dir_code,
        });
        modal.onclose = () => {
          this.search();
        };
      }
    },
  },
};
</script>
