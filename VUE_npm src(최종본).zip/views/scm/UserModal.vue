<template>
  <div
    id="user"
    class="layerPop layerType2"
    style="width: 784px; display: table"
  >
    <dl>
      <dt>
        <strong>{{ title }}</strong>
      </dt>
      <dd class="content">
        <table class="row" style="width: 790px">
          <caption>
            caption
          </caption>
          <colgroup>
            <col width="15%" />
            <col width="15%" />
            <col width="20%" />
            <col width="15%" />
            <col width="15%" />
            <col width="20%" />
          </colgroup>

          <tbody>
            <tr>
              <th scope="row" rowspan="3">
                <select
                  id="checkstaff"
                  name="checkstaff"
                  style="width: 80px"
                  v-model="checkstaff"
                  @change="changestaff()"
                >
                  <option value="instaff">내부직원</option>
                  <option value="outstaff">기업고객</option>
                </select>
              </th>

              <th scope="row">아이디 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  name="rloginID"
                  id="rloginID"
                  style="width: 160px"
                  v-model="rloginID"
                />
                <a
                  id="duplicate_check"
                  name="btn"
                  style="border: 1px solid"
                  @click="idcheck()"
                  >중복체크</a
                >
              </td>

              <th scope="row">비밀번호<span class="font_red">*</span></th>
              <td>
                <input
                  type="password"
                  name="password"
                  id="password"
                  style="width: 160px"
                  v-model="password"
                />
              </td>
            </tr>

            <tr>
              <th scope="row">연락처 <span class="font_red">*</span></th>
              <td>
                <input
                  style="width: 160px"
                  type="text"
                  id="hp"
                  name="hp"
                  v-model="hp"
                />
              </td>
              <th scope="row">이메일</th>
              <td>
                <input
                  type="text"
                  name="email"
                  id="email"
                  size="30"
                  v-model="email"
                />
              </td>
            </tr>
            <tr id="instaff" v-show="instaff">
              <th scope="row">직원명<span class="font_red">*</span></th>
              <td>
                <input type="text" name="name" id="name" v-model="name" />
              </td>
              <th scope="row">담당업무<span class="font_red">*</span></th>
              <td>
                <select id="checkcha" name="checkcha" v-model="checkcha">
                  <option value="A">SCM담당자</option>
                  <option value="B">배송담당자</option>
                  <option value="D">구매담당자</option>
                  <option value="E">회사임원</option>
                </select>
              </td>
            </tr>
            <tr id="outstaff" v-show="outstaff">
              <th scope="row">회사명<span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  name="company"
                  id="company"
                  v-model="company"
                />
              </td>
              <th scope="row">담당자명<span class="font_red">*</span></th>
              <td>
                <input type="text" name="name" id="name" v-model="name" />
              </td>
            </tr>
            <tr>
              <th scope="row">우편번호<span class="font_red">*</span></th>
              <td colspan="4">
                <input
                  type="text"
                  name="zipcode"
                  id="zipcode"
                  v-model="zipcode"
                />
                <input
                  type="button"
                  value="우편번호 찾기"
                  style="height: 20px"
                  @click="post"
                />
              </td>
            </tr>
            <tr>
              <th scope="row">주소<span class="font_red">*</span></th>
              <td colspan="4">
                <input
                  type="text"
                  name="address"
                  id="address"
                  size="100"
                  v-model="address"
                />
              </td>
            </tr>
            <tr>
              <th scope="row">상세주소<span class="font_red">*</span></th>
              <td colspan="4">
                <input
                  type="text"
                  name="dtl_add"
                  id="dtl_add"
                  size="100"
                  v-model="dtl_add"
                />
              </td>
            </tr>
            <tr id="outstaff_account" v-show="outstaff">
              <th scope="row">계좌번호<span class="font_red">*</span></th>
              <td colspan="2">
                <input
                  type="text"
                  name="account"
                  id="account"
                  size="30"
                  v-model="account"
                />
              </td>

              <th scope="row">은행명<span class="font_red">*</span></th>
              <td>
                <select id="checkbank" name="checkbank" v-model="checkbank">
                  <option value="cityB">씨티은행</option>
                  <option value="hanaB">하나은행</option>
                  <option value="ibkB">기업은행</option>
                  <option value="kakaoB">카카오뱅크</option>
                  <option value="kB">국민은행</option>
                  <option value="nhB">농협</option>
                  <option value="shinhanB">신한은행</option>
                  <option value="uriB">우리은행</option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="btn_areaC mt30">
          <a
            class="btn btn-primary mx-2"
            id="btnUpdateUser"
            name="btn"
            v-show="!pactionflag"
            @click="save()"
            ><span>수정</span></a
          >
          <a
            class="btn btn-primary mx-2"
            id="btnSaveUser"
            name="btn"
            v-show="pactionflag"
            @click="save()"
            ><span>등록</span></a
          >
        </div>
      </dd>
    </dl>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';

export default {
  props: { ptitle: String, loginID: String, action: String, divcd: String },
  data: function () {
    return {
      ID: this.loginID,
      title: this.ptitle,
      paction: this.action,
      div: this.divcd,
      checkstaff: 'instaff',
      password: '',
      hp: '',
      email: '',
      zipcode: '',
      address: '',
      dtl_add: '',
      name: '',
      checkbank: 'cityB',
      checkcha: 'A',
      account: '',
      company: '',
      rloginID: '',
      idcheckresult: '',
      readonly: false,
      instaff: false,
      outstaff: true,
      optionflag: true,
      pactionflag: true,
    };
  },
  // html 로딩, 가상 dom 실행, 이 두 개 연결 시 작동
  mounted: function () {
    this.init();
  },
  methods: {
    init: function () {
      if (this.paction == 'I') {
        //신규
        this.pactionflag = true;
        this.instaff = true;
        this.outstaff = false;
      } else {
        //수정
        this.pactionflag = false;
        this.optionflag = false;
        this.readonly = true;
        this.detail();
      }
    },
    detail: function () {
      let vm = this;
      // 신규 등록 시
      if (this.pactionflag) {
        //alert('신규 모달 - 구분 : ' + this.div + ' loginID : ' + this.ID);
      } else {
        //alert('수정 모달 - ' + this.div + ' loginID : ' + this.ID);
        //  수정 시
        let params = new URLSearchParams();
        params.append('loginID', this.ID);

        if (this.div == 'instaff') {
          this.instaff = true;
          this.outstaff = false;
        } else {
          this.instaff = false;
          this.outstaff = true;
        }

        this.axios
          .post('/scm/detailUser.do', params)
          .then(function (response) {
            //alert('save callback : ' + JSON.stringify(response));
            vm.checkstaff = response.data.result.div_cd;
            vm.rloginID = response.data.result.loginID;
            vm.password = response.data.result.password;
            vm.hp = response.data.result.hp;
            vm.email = response.data.result.email;
            vm.name = response.data.result.name;
            vm.checkcha = response.data.result.user_type;
            vm.company = response.data.result.company;
            vm.zipcode = response.data.result.zip;
            vm.address = response.data.result.addr;
            vm.dtl_add = response.data.result.dtl_add;
            vm.account = response.data.result.account;
            vm.checkbank = response.data.result.bank;
          })
          .catch(function (error) {
            alert('에러! API 요청에 오류가 있습니다. ' + error);
          });
      }
    },
    idcheck: function () {
      let vm = this;
      let params = new URLSearchParams();

      params.append('checkid', this.rloginID);

      if (this.rloginID == null || this.rloginID == '') {
        alert('ID를 입력하세요!');
      } else {
        this.axios
          .post('/scm/check_loginID.do', params)
          .then(function (response) {
            //alert('callback : ' + JSON.stringify(response));
            vm.idcheckresult = response.data.result;

            if (vm.idcheckresult == 1) {
              alert('중복된 ID가 있습니다!');
              document.getElementById('rloginID').focus();
            } else {
              alert('사용가능한 ID입니다!');
            }
          })
          .catch(function (error) {
            alert('에러! API 요청에 오류가 있습니다. ' + error);
          });
      }
    },
    save: function () {
      //let vm = this;
      let params = new URLSearchParams();
      //let checkparams = {};

      params.append('password', this.password);
      params.append('hp', this.hp);
      params.append('email', this.email);
      params.append('zip', this.zipcode);
      params.append('addr', this.address);
      params.append('dtl_add', this.dtl_add);
      params.append('name', this.name);
      params.append('chaCD', this.checkcha);
      params.append('bank', this.checkbank);
      params.append('account', this.account);
      params.append('company', this.company);
      params.append('rloginID', this.rloginID);
      params.append('action', this.paction);
      params.append('checkstaff', this.checkstaff);
      let IfNull = {};
      if (this.checkstaff == 'instaff') {
        IfNull = {
          password: '비밀번호를 입력하세요!',
          hp: '연락처를 입력하세요!',
          email: '이메일을 입력하세요!',
          zip: '우편번호를 입력하세요!',
          addr: '주소를 입력하세요!',
          dtl_add: '상세주소를 입력하세요!',
          name: '이름을 입력하세요!',
          rloginID: '아이디를 입력하세요!',
        };
      } else {
        IfNull = {
          password: '비밀번호를 입력하세요!',
          hp: '연락처를 입력하세요!',
          email: '이메일을 입력하세요!',
          zip: '우편번호를 입력하세요!',
          addr: '주소를 입력하세요!',
          dtl_add: '상세주소를 입력하세요!',
          name: '담당자명을 입력하세요!',
          rloginID: '아이디를 입력하세요!',
          company: '회사를 입력하세요!',
          bank: '은행을 입력하세요!',
          account: '계좌를 입력하세요!',
        };
      }

      if (this.findnull(params, IfNull)) {
        if (this.paction == 'U') {
          confirm('수정하시겠습니까?');
        } else {
          confirm('저장하시겠습니까?');
        }

        this.axios
          .post('/scm/userSave.do', params)
          .then(function (response) {
            console.log(response);
            let msg = response.data.resultMsg;
            if (msg == 'UPDATED' || msg == 'SUCCESS') {
              alert('성공!');
              closeModal();
            } else {
              alert('오류!');
            }
          })
          .catch(function (error) {
            alert('에러! API 요청에 오류가 있습니다. ' + error);
          });
      }
    },
    changestaff: function () {
      if (this.checkstaff == 'instaff') {
        this.outstaff = false;
        this.instaff = true;
      } else {
        this.instaff = false;
        this.outstaff = true;
      }
    },
    post() {
      new window.daum.Postcode({
        oncomplete: (data) => {
          // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

          // 도로명 주소의 노출 규칙에 따라 주소를 조합한다.
          // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
          let fullRoadAddr = data.roadAddress; // 도로명 주소 변수
          let extraRoadAddr = ''; // 도로명 조합형 주소 변수

          // 법정동명이 있을 경우 추가한다. (법정리는 제외)
          // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
            extraRoadAddr += data.bname;
          }
          // 건물명이 있고, 공동주택일 경우 추가한다.
          if (data.buildingName !== '' && data.apartment === 'Y') {
            extraRoadAddr +=
              extraRoadAddr !== ''
                ? ', ' + data.buildingName
                : data.buildingName;
          }
          // 도로명, 지번 조합형 주소가 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
          if (extraRoadAddr !== '') {
            extraRoadAddr = ' (' + extraRoadAddr + ')';
          }
          // 도로명, 지번 주소의 유무에 따라 해당 조합형 주소를 추가한다.
          if (fullRoadAddr !== '') {
            fullRoadAddr += extraRoadAddr;
          }
          // 우편번호와 주소 정보를 해당 필드에 넣는다.
          this.zipcode = data.zonecode; //5자리 새우편번호 사용
          this.address = fullRoadAddr;
          document.getElementById('dtl_add').focus();
        },
      }).open();
    },
    findnull: function (params, IfNull) {
      let keys = Object.keys(IfNull);
      let paramsKeys = [];
      let paramsValues = [];

      params.forEach((value, key) => {
        paramsKeys.push(key);
        paramsValues.push(value);
      });
      if (this.checkstaff == 'instaff') {
        for (var i = 0; i < paramsKeys.length; i++) {
          if (
            paramsKeys[i] != 'account' &&
            paramsKeys[i] != 'bank' &&
            paramsKeys[i] != 'company' &&
            (paramsValues[i] == null || paramsValues[i] == '')
          ) {
            // 내부직원
            for (var j = 0; j < keys.length; j++) {
              if (keys[j] == paramsKeys[i]) {
                alert(IfNull[keys[j]]);
                return false;
              }
            }
          }
        }
      }
      if (this.checkstaff == 'outstaff') {
        for (var n = 0; n < paramsKeys.length; n++) {
          if (
            paramsKeys[n] != 'chaCD' &&
            (paramsValues[n] == null || paramsValues[n] == '')
          ) {
            // 기업고객
            for (var m = 0; m < keys.length; m++) {
              if (keys[m] == paramsKeys[n]) {
                alert(IfNull[keys[m]]);
                return false;
              }
            }
          }
        }
      }

      return true;
    },
  },
};
</script>
