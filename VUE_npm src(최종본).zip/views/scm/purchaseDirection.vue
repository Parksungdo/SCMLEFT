<template>
  <div id="comnCodMgr">
    <p class="Location">
      <a href="/dashboard/home" class="btn_set home"></a>
      <span class="btn_nav bold">작업지시서</span>
      <span class="btn_nav bold">발주지시서</span>
      <a href="../system/comnCodMgr.do" class="btn_set refresh">새로고침</a>
    </p>

    <!-- 검색 영역 -->
    <div id="divSearchBar">
      <p class="conTitle" id="searcharea">
        <span>발주 지시서 목록</span>
        <span id="search" class="fr">
          <select id="type" name="type" v-model="type">
            <option value="all" selected="selected">전체</option>
            <option value="companyName">업체명</option>
            <option value="modelName">제품종류</option>
            <option value="pdName">제품명</option>
          </select>
          <input
            class="datetype"
            type="date"
            id="startDate"
            name="startDate"
            v-model="startDate"
          />
          <input
            class="datetype"
            type="date"
            id="endDate"
            name="endDate"
            v-model="endDate"
          />
          <input
            type="text"
            id="keyword"
            name="keyword"
            style="height: 27px"
            v-model="keyword"
          />
          <a @click="search()" class="btn btn-primary mx-2" name="search">
            <span>검색</span>
          </a>
        </span>
      </p>
    </div>

    <!-- 발주지시서 리스트 영역 -->
    <div id="divPurchaseList">
      <table class="col">
        <colgroup>
          <col width="8%" />
          <col width="10%" />
          <col width="10%" />
          <col width="20%" />
          <col width="8%" />
          <col width="10%" />
          <col width="10%" />
          <col width="10%" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col">발주번호</th>
            <th scope="col">발주업체</th>
            <th scope="col">발주제품종류</th>
            <th scope="col">발주제품명</th>
            <th scope="col">발주수량</th>
            <th scope="col">저장창고</th>
            <th scope="col">날짜</th>
            <th scope="col">발주진행상태</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="totalCnt == 0">
            <tr>
              <td colspan="9">일치하는 검색 결과가 없습니다</td>
            </tr>
          </template>
          <template v-else>
            <tr v-for="item in list" :key="item.bordCode">
              <td>{{ item.bordCode }}</td>
              <td>{{ item.companyName }}</td>
              <td>{{ item.modelName }}</td>
              <td>{{ item.pdName }}</td>
              <td>{{ item.bordAmt }}</td>
              <td>{{ item.whName }}</td>
              <td>{{ item.dirDate }}</td>
              <td>{{ item.bordType }}</td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
    <div id="purchasePagination">
      <paginate
        class="justify-content-center"
        v-model="pageNum"
        :page-count="totalPage"
        :page-range="5"
        :margin-pages="0"
        :click-handler="search"
        :prev-text="'Prev'"
        :next-text="'Next'"
        :container-class="'pagination'"
        :page-class="'page-item'"
      >
      </paginate>
    </div>
  </div>
</template>
<script>
import Paginate from 'vuejs-paginate-next';

export default {
  components: {
    paginate: Paginate,
  },
  data: function () {
    return {
      pageNum: 1,
      listCount: 10,
      totalPage: 1,
      totalCnt: 0,
      type: 'all',
      keyword: '',
      startDate: '',
      endDate: '',
      list: [],
    };
  },
  mounted() {
    this.search();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      params.append('pageNum', this.pageNum);
      params.append('listCount', this.listCount);
      params.append('type', this.type);
      params.append('keyword', this.keyword);
      params.append('startDate', this.startDate.replaceAll('-', ''));
      params.append('endDate', this.endDate.replaceAll('-', ''));

      console;

      this.axios
        .post('/scm/searchPurDirectionList', params)
        .then(function (response) {
          console.log(response.data);
          vm.list = response.data.result.purDirectionList;
          vm.totalCnt = response.data.result.purDirectionCount;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러' + error);
        });
    },
    page: function () {
      var total = this.totalCnt;
      var page = this.listCount;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
  },
};
</script>
