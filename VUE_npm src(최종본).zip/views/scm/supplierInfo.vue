<template>
  <div id="container">
    <ul>
      <li class="contents">
        <div class="content">
          <p class="Location">
            <a class="btn_set home">메인으로</a>
            <a class="btn_nav">기준 정보</a>
            <span class="btn_nav bold">납품 업체 정보</span>
          </p>

          <p class="conTitle">
            <span>납품 업체 정보</span>
            <span class="fr">
              <select
                id="select"
                name="select"
                style="width: 100px"
                v-model="select"
              >
                <option value="">전체</option>
                <option value="supplier">납품 업체</option>
                <option value="product">제품명</option>
              </select>
              <input
                type="text"
                style="width: 160px; height: 30px"
                id="search"
                name="search"
                v-model="search"
              />
              <a
                class="btn btn-primary mx-2"
                id="searchBtn"
                name="btn"
                @click="supplierlist()"
              >
                <span>검색</span>
              </a>
              <a class="btn btn-primary mx-2" name="modal" @click="insert">
                <span>신규등록</span>
              </a>
            </span>
          </p>

          <div id="supplier">
            <table class="col">
              <caption>
                caption
              </caption>
              <colgroup>
                <col width="5%" />
                <col width="9%" />
                <col width="9%" />
                <col width="6%" />
                <col width="10%" />
                <col width="10%" />
                <col width="9%" />
                <col width="6%" />
              </colgroup>

              <thead>
                <tr>
                  <th scope="col">번호</th>
                  <th scope="col">납품업체명</th>
                  <th scope="col">LOGINID</th>
                  <th scope="col">패스워드</th>
                  <th scope="col">담당자명</th>
                  <th scope="col">담당자 연락처</th>
                  <th scope="col">담당자 이메일</th>
                  <th scope="col">비고</th>
                </tr>
              </thead>

              <tbody>
                <tr
                  id="listInf"
                  v-for="item in supplier.supplierlist"
                  :key="item.napcode"
                >
                  <td @click="productrowc(item.loginID)">{{ item.napcode }}</td>
                  <td @click="productrowc(item.loginID)">{{ item.company }}</td>
                  <td @click="productrowc(item.loginID)">{{ item.loginID }}</td>
                  <td @click="productrowc(item.loginID)">
                    {{ item.password }}
                  </td>
                  <td @click="productrowc(item.loginID)">{{ item.name }}</td>
                  <td @click="productrowc(item.loginID)">{{ item.hp }}</td>
                  <td @click="productrowc(item.loginID)">{{ item.email }}</td>
                  <td>
                    <a
                      class="btn btn-primary mx-2"
                      id="btnUpdateSupplier"
                      name="btn"
                      @click="insert(item.loginID, item.napcode)"
                      ><span>수정</span></a
                    >
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <paginate
            class="justify-content-center"
            v-model="supplier.currentPage"
            :page-count="supplier.totalPage"
            :page-range="5"
            :margin-pages="0"
            :click-handler="supplierlist"
            :prev-text="'Prev'"
            :next-text="'Next'"
            :container-class="'pagination'"
            :page-class="'page-item'"
          >
          </paginate>

          <p class="conTitle mt50">
            <span>제품 정보</span>
          </p>

          <div id="product" v-show="productflag">
            <table class="col">
              <caption>
                caption
              </caption>
              <colgroup>
                <col width="36%" />
                <col width="32%" />
                <col width="32%" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">제품번호</th>
                  <th scope="col">제품명</th>
                  <th scope="col">제조사</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="product.totalCnt == 0">
                  <td colspan="5" class="text-center">
                    <strong>해당 업체에 등록된 제품이 없습니다</strong>
                  </td>
                </tr>
                <tr v-for="list in product.productlist" :key="list.pd_CODE">
                  <td>{{ list.pd_CODE }}</td>
                  <td>{{ list.pd_NAME }}</td>
                  <td>{{ list.pd_CORP }}</td>
                </tr>
                <tr v-show="!productflag">
                  <td colspan="12">납품 업체를 선택해 주세요.</td>
                </tr>
              </tbody>
            </table>

            <paginate
              class="justify-content-center"
              v-model="product.currentPage"
              :page-count="product.totalPage"
              :page-range="5"
              :margin-pages="0"
              :click-handler="productlist"
              :prev-text="'Prev'"
              :next-text="'Next'"
              :container-class="'pagination'"
              :page-class="'page-item'"
            >
            </paginate>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { openModal } from 'jenesius-vue-modal';
import Paginate from 'vuejs-paginate-next';
import supplierModal from './supplierModal.vue';

export default {
  data: function () {
    return {
      productflag: false,
      select: '',
      search: '',
      sloginID: '',
      supplier: {
        currentPage: 1,
        totalCnt: 0,
        totalPage: 1,
        pageSize: 5,
        supplierlist: [],
        action: '',
        loginID: '',
      },
      product: {
        currentPage: 1,
        totalCnt: 0,
        totalPage: 1,
        pageSize: 5,
        productlist: [],
        action: '',
        loginID: '',
      },
    };
  },
  mounted() {
    this.supplierlist();
  },
  components: {
    paginate: Paginate,
  },
  methods: {
    supplierlist: function () {
      this.productflag = false;
      let vm = this;
      let params = new URLSearchParams();

      params.append('currentPage', this.supplier.currentPage);
      params.append('pageSize', this.supplier.pageSize);
      params.append('search', this.search);
      params.append('select', this.select);

      this.axios
        .post('/scm/SupplierListVue.do', params)
        .then(function (response) {
          console.log('callbackZZ : ' + JSON.stringify(response));

          vm.supplier.supplierlist = response.data.SupplierList;
          console.log(
            'vm.supplier.supplierlist : ' +
              JSON.stringify(vm.supplier.supplierlist.getters)
          );
          vm.supplier.totalCnt = response.data.SupplierCnt;
          // vm.supplier.loginID = response.data.supplierlist.loginID;
          //vm.search = response.search;
          //vm.option = response.option;
          vm.supplier.totalPage = vm.pageSupplier();
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    insert: async function (loginID, napCD) {
      if (napCD == '' || napCD == null) {
        this.action = 'I';

        const modal = await openModal(supplierModal, {
          ptitle: '납품 업체 신규 등록',
          loginID: '',
          napcode: '',
          action: this.action,
        });

        modal.onclose = () => {
          console.log('Close ');
          this.supplierlist();
        };
      } else {
        this.action = 'U';

        const modal = await openModal(supplierModal, {
          ptitle: '납품 업체 정보 수정',
          loginID: loginID,
          napcode: napCD,
          action: this.action,
        });

        modal.onclose = () => {
          console.log('Close ');
          this.supplierlist();
        };
      }
    },
    productrowc: function (loginID) {
      this.sloginID = loginID;
      this.productlist();
    },
    productlist: function () {
      this.productflag = true;
      let vm = this;
      let params = new URLSearchParams();
      console.log('loginID : ' + this.sloginID);

      params.append('currentPage', this.product.currentPage);
      params.append('pageSize', this.product.pageSize);
      params.append('search', this.search);
      params.append('select', this.select);
      params.append('loginID', this.sloginID);

      this.axios
        .post('/scm/ProductListVue.do', params)
        .then(function (response) {
          console.log('callback : ' + JSON.stringify(response));

          vm.product.productlist = response.data.ProductList;
          vm.product.totalCnt = response.data.ProductCnt;
          //vm.search = response.search;
          //vm.option = response.option;
          vm.product.totalPage = vm.pageProduct();
          console.log(vm.product.productlist);
          //vm.sloginID = loginID;
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
    pageSupplier: function () {
      var total = this.supplier.totalCnt;
      var page = this.supplier.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
    pageProduct: function () {
      var total = this.product.totalCnt;
      var page = this.product.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;

        return result;
      }
    },
  },
};
</script>

<style scoped>
#searchArea {
  margin-top: 35px;
  padding: 50px 0;
  border: 2px solid rgb(190, 190, 190);
}
#suppliers > table > tbody > tr {
  cursor: pointer;
}
#suppliers > table > tbody > tr:hover {
  background-color: #fafa5f;
}
</style>
