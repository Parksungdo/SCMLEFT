<template>
  <div
    id="suppliersave"
    class="layerPop layerType2"
    style="width: 677px; display: table"
  >
    <dl>
      <dt>
        <strong>{{ title }}</strong>
      </dt>
      <dd class="content">
        <table class="row">
          <caption>
            caption
          </caption>
          <colgroup>
            <col width="15%" />
            <col width="15%" />
            <col width="20%" />
            <col width="15%" />
            <col width="15%" />
            <col width="20%" />
          </colgroup>
          <tbody>
            <tr>
              <th scope="row">
                납품 업체 번호 <span class="font_red">*</span>
              </th>
              <td colspan="3">
                <templete>
                  <input
                    type="text"
                    class="inputTxt p100"
                    name="napcode"
                    id="napcode"
                    v-model="nap"
                    readonly
                  />
                </templete>
              </td>
            </tr>
            <tr>
              <th scope="row">납품업체명 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="company"
                  id="company"
                  v-model="company"
                />
              </td>
              <th scope="row">LoginID<span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="loginID"
                  id="loginID"
                  v-model="ID"
                  :readonly="readonly"
                />
              </td>
            </tr>
            <tr>
              <th scope="row">패스워드 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="password"
                  id="password"
                  v-model="password"
                />
              </td>
              <th scope="row">담당자명 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="name"
                  id="name"
                  v-model="name"
                />
              </td>
            </tr>
            <tr>
              <th scope="row">담당자 연락처 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="hp"
                  id="hp"
                  v-model="hp"
                />
              </td>
              <th scope="row">담당자 이메일 <span class="font_red">*</span></th>
              <td>
                <input
                  type="text"
                  class="inputTxt p100"
                  name="email"
                  id="email"
                  v-model="email"
                />
              </td>
            </tr>
          </tbody>
        </table>

        <div class="btn_areaC mt30" @click="save">
          <a
            class="btnType blue"
            id="btnSaveSupplier"
            name="btn"
            v-show="!pactionflag"
            ><span>등록</span></a
          >
          <a
            class="btnType blue"
            id="btnSaveSupplier"
            name="btn"
            v-show="pactionflag"
            ><span>수정</span></a
          >
        </div>
      </dd>
    </dl>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';

export default {
  props: { ptitle: String, loginID: String, action: String, napcode: Number },
  data: function () {
    return {
      ID: this.loginID,
      title: this.ptitle,
      paction: this.action,
      nap: this.napcode,
      company: '',
      password: '',
      name: '',
      hp: '',
      email: '',

      pactionflag: true,
      readonly: true,
    };
  },
  // html 로딩, 가상 dom 실행, 이 두 개 연결 시 작동
  mounted: function () {
    this.init();
  },
  methods: {
    init: function () {
      let params = new URLSearchParams();
      let vm = this;

      params.append('action', this.paction);
      params.append('loginID', this.ID);

      if (this.paction == 'I') {
        // 신규
        this.pactionflag = false;
        this.readonly = false;
      } else {
        //수정
        this.pactionflag = true;
        this.readonly = true;

        this.axios
          .post('/scm/DetailSupplier.do', params)
          .then(function (response) {
            //alert('save callback : ' + JSON.stringify(response));
            vm.password = response.data.result.password;
            vm.hp = response.data.result.hp;
            vm.email = response.data.result.email;
            vm.name = response.data.result.name;
            vm.company = response.data.result.company;
          })
          .catch(function (error) {
            alert('에러! API 요청에 오류가 있습니다. ' + error);
          });
      }
    },
    save: function () {
      let params = new URLSearchParams();

      if (this.paction == 'I') {
        // 신규
        this.pactionflag = false;
        this.readonly = false;
      } else {
        //수정
        this.pactionflag = true;
        this.readonly = true;
        params.append('napcode', this.napcode);
      }

      params.append('action', this.paction);
      params.append('company', this.company);
      params.append('email', this.email);
      params.append('password', this.password);
      params.append('name', this.name);
      params.append('hp', this.hp);
      params.append('loginID', this.ID);

      this.axios
        .post('/scm/SupplierSave.do', params)
        .then(function (response) {
          //alert('resultMsg : ' + response.data.resultMsg);
          let msg = response.data.resultMsg;
          if (msg == 'UPDATE' || msg == 'SUCCESS') {
            alert('성공!');
            closeModal();
          } else {
            alert('오류!');
          }
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
  },
};
</script>
