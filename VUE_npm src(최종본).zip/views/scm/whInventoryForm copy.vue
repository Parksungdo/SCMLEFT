<template>
  <p class="Location">
    <a href="../dashboard/dashboard.do" class="btn_set home">메인으로</a>
    <span class="btn_nav bold">거래내역</span>
    <span class="btn_nav bold">창고별 재고 현황</span>
    <a href="../system/comnCodMgr.do" class="btn_set refresh">새로고침</a>
  </p>

  <p class="conTitle">
    <span>창고별 재고 현황</span>
    <span class="fr d-flex">
      <select class="form-control h-auto mx-2" v-model="select">
        <option value="">전체</option>
        <option value="0">창고 명</option>
        <option value="1">제품 명</option>
      </select>
      <input
        type="text"
        class="form-control"
        style="width: 200px"
        v-model="searchword"
      />
      <a @click="search()" class="btnType blue" name="search">
        <span>검색</span>
      </a>
    </span>
  </p>

  <div class="mt-5">
    <table class="col">
      <thead>
        <tr>
          <th scope="col">창고 코드</th>
          <th scope="col">제품 번호</th>
          <th scope="col">창고명</th>
          <th scope="col">제품 명</th>
          <th scope="col">재고 수량</th>
          <th scope="col">창고 위치</th>
        </tr>
      </thead>
      <tbody>
        <template v-if="totalCount == 0">
          <tr>
            <td colspan="6">일치하는 검색 결과가 없습니다</td>
          </tr>
        </template>
        <template v-else>
          <tr
            v-for="item in list"
            :key="item.model_code"
            @click="
              currentSituation(item.model_code, item.wh_code, currentPage)
            "
          >
            <td>{{ item.wh_code }}</td>
            <td>
              {{ item.model_code }}
            </td>
            <td>{{ item.wh_name }}</td>
            <td>{{ item.pd_name }}</td>
            <td>{{ item.wh_stock }}</td>
            <td>{{ item.wh_addr }}</td>
          </tr>
        </template>
      </tbody>
    </table>
  </div>

  <Pagination
    class="mt-4 justify-content-center"
    v-model="currentPage"
    :page-count="totalPage"
    :page-range="5"
    :margin-pages="0"
    :click-handler="search"
    :prev-text="'이전'"
    :next-text="'다음'"
    :prev-class="'prev'"
    :container-class="'pagination'"
    :page-class="'page-item'"
  >
  </Pagination>

  <h5 style="font-size: 25px">입/출고 현황</h5>
  <br />

  <div class="divComDtlCodList">
    <table class="col">
      <caption>
        caption
      </caption>
      <colgroup>
        <col width="25%" />
        <col width="25%" />
        <col width="25%" />
        <col width="25%" />
      </colgroup>

      <thead>
        <tr>
          <th scope="col">제품 번호</th>
          <th scope="col">제품 명</th>
          <th scope="col">입고 량</th>
          <th scope="col">출고 량</th>
        </tr>
      </thead>
      <tbody id="listComnDtlCod">
        <tr v-for="item in clist" :key="item.model_code">
          <td>{{ item.model_code }}</td>
          <td>{{ item.pd_name }}</td>
          <td>{{ item.input }}</td>
          <td>{{ item.output }}</td>
        </tr>
      </tbody>
    </table>
  </div>
  <Paginate
    class="mt-4 justify-content-center"
    v-model="currentPagec"
    :page-count="totalPage"
    :page-range="2"
    :margin-pages="0"
    :click-handler="currentSituation()"
    :prev-text="'이전'"
    :next-text="'다음'"
    :prev-class="'prev'"
    :container-class="'pagination'"
    :page-class="'page-item'"
  >
  </Paginate>
</template>

<script>
import Paginate from 'vuejs-paginate-next';

export default {
  components: {
    Pagination: Paginate,
    Paginate: Paginate,
  },
  data: function () {
    return {
      currentPage: 1,
      pageSize: 5,
      totalCount: 0,
      totalPage: 1,
      select: '',
      searchword: '',
      list: [],
      clist: [],
      currentPagec: 1,
      cpageSize: 3,
      totalCnt: 0,
      ctotalpage: 1,
    };
  },
  mounted() {
    this.search();
    this.currentSituation();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);
      params.append('select', this.select);
      params.append('searchword', this.searchword);

      this.axios
        .post('/scm/listLecList.do', params)
        .then(function (response) {
          console.log(response.data);
          vm.list = response.data.WHInventoryFormModel;
          vm.totalCount = response.data.totalCntAdmsmtLecList;
          vm.totalPage = vm.page();
        })
        .catch(function (error) {
          alert('에러 : ' + error);
        });
    },
    currentSituation: function (model_code, wh_code) {
      console.log('현황 들어옴');
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      params.append('currentPage', this.currentPagec);
      //params.append('currentPagec', currentPage);
      params.append('pageSize', this.cpageSize);
      params.append('li_no', model_code);
      params.append('wh_code', wh_code);

      this.axios
        .post('/scm/listLecPersonList.do', params)
        .then(function (resp) {
          console.log('axios 들어옴');
          console.log(resp);
          vm.clist = resp.data.admsmtLecPersonListMgtModel;
          vm.totalcnt = resp.data.totalCntAdmsmtLecPersonList;
          vm.ctotalpage = vm.cpage();
        })
        .catch(function (error) {
          alert('에러 : ' + error);
        });
    },
    page: function () {
      var total = this.totalCount;
      var page = this.pageSize;
      var xx = total % page;
      var result = parseInt(total / page);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
    cpage: function () {
      var ctotal = this.totalCnt;
      var cpage = this.cpageSize;
      var xx = ctotal % cpage;
      var result = parseInt(ctotal / cpage);

      if (xx == 0) {
        return result;
      } else {
        result = result + 1;
        return result;
      }
    },
  },
};
</script>

<style scoped>
#searchGroup {
  width: 50%;
  height: 35px;
  position: relative;
  top: 50%;
  transform: translate(0, -50%);
}
#searchGroup > select {
  height: auto;
}
#detailArea {
  margin: 20px auto;
  padding: 0;
  animation: showUp 0.7s ease-out;
}
#whlist > tr {
  cursor: pointer;
}
#whlist > tr.blur {
  animation: blur normal 2s infinite ease-in-out;
}
@keyframes blur {
  0% {
    background-color: white;
  }
  50% {
    background-color: #fafa5f;
  }
  100% {
    background-color: white;
  }
}
@keyframes showUp {
  0% {
    opacity: 0;
    transform: translateX(-100%);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}
.fr {
  display: flex;
}
</style>
