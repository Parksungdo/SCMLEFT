<template>
  <dl id="grpInfoWrap">
    <dd class="content">
      <!-- s : 여기에 내용입력 -->
      <table id="grpInfo" width="500px">
        <caption>
          caption
        </caption>
        <colgroup>
          <col width="50px" />
          <col width="*" />
        </colgroup>

        <tbody>
          <tr>
            <td colspan="2" class="text-center">
              <div class="my-4">
                <strong style="font-size: 30px">{{ ptitle }}</strong>
              </div>
            </td>
          </tr>

          <tr>
            <th scope="row">제목 <span class="font_red">*</span></th>
            <td>
              <input
                type="text"
                class="form-control"
                name="title"
                id="title"
                v-model="title"
              />
            </td>
          </tr>
          <tr>
            <th scope="row">내용 <span class="font_red">*</span></th>
            <td>
              <textarea
                class="inputTxt p100"
                name="cont"
                id="cont"
                style="height: 155px"
                v-model="cont"
              />
            </td>
          </tr>
        </tbody>
      </table>

      <!-- e : 여기에 내용입력 -->

      <div class="btn_areaC mt30">
        <a
          @click="save()"
          class="btn btn-primary"
          id="btnSaveGrpCod"
          name="btn"
        >
          <span>저장</span>
        </a>
        <a @click="deletefrpcd()" class="btn btn-danger mx-2" v-show="delshow">
          <span>삭제</span>
        </a>
      </div>
    </dd>
  </dl>
</template>

<script>
import { closeModal } from 'jenesius-vue-modal';
export default {
  // vue에서는 받아온 변수를 methods에서 직접 핸들링이 불가능하기 때문에
  // 임시 변수를 만들어서 받아온 변수를 넣어 줘야 함
  props: { ptitle: String, selnoticeno: Number, action: String },
  data: function () {
    return {
      noticeno: this.selnoticeno,
      title: '',
      cont: '',
      delshow: false,
      paction: this.action,
    };
  },
  computed: {
    agrpcd: {
      get: function () {
        return this.data.pgrpcd;
      },
      set: function (v) {
        this.data.pgrpcd = v;
      },
    },
  },
  // html 로딩, 가상 dom 실행, 이 두 개 연결 시 작동
  mounted: function () {
    let vm = this;
    // 신규 등록 시
    if (this.selnoticeno == null || this.selnoticeno == '') {
      vm.title = '';
      vm.cont = '';
      vm.delshow = false;
    } else {
      //  수정 시 (grp_cod 에 해당하는 상세코드 정보 가져오기)
      let params = new URLSearchParams();
      params.append('noticeno', this.noticeno);

      this.axios
        .post('/scm/selectnotice.do', params)
        .then(function (response) {
          console.log(response);

          vm.title = response.data.selectresult[0].nottitle;
          vm.cont = response.data.selectresult[0].notcon;

          vm.delshow = true;
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    }
  },
  methods: {
    save: function () {
      if (confirm('저장하시겠습니까?')) {
        //let vm = this;
        let params = new URLSearchParams();
        params.append('title', this.title);
        params.append('cont', this.cont);
        params.append('noticeno', this.noticeno);
        params.append('action', this.paction);

        this.axios
          .post('/scm/savenotice.do', params)
          .then(function (response) {
            console.log(response);
            let status = response.status;
            let msg = response.data.result;
            if (status == 200) {
              alert('저장이 완료 되었습니다.');
              closeModal();
            } else {
              alert(msg);
            }
          })
          .catch(function (error) {
            alert('에러! API 요청에 오류가 있습니다. ' + error);
          });
      }
    },
    deletefrpcd: function () {
      this.paction = 'D';
      this.save();
    },
  },
  created() {
    // 자식요소에서 부모 요소 method 호출
  },
};
</script>

<style>
#grpInfo {
  border-collapse: separate;
  border-spacing: 20px;
}
#grpInfoWrap {
  background-color: #fff;
  padding: 3rem;
  border-radius: 10px;
  border: 2px solid rgb(59, 59, 59);
}
</style>
