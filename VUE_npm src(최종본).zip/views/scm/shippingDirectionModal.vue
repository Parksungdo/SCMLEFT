<template>
  <div id="grpInfoWrap" style="width: 53.8rem">
    <dl>
      <dt>
        <strong>배송지시서 상세보기</strong>
      </dt>
      <dd class="content">
        <table class="col">
          <colgroup>
            <col width="8%" />
            <col width="6%" />
            <col width="8%" />
            <col width="8%" />
            <col width="6%" />
            <col width="10%" />
            <col width="7%" />
            <col width="6%" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col">주문 일자</th>
              <th scope="col">주문 번호</th>
              <th scope="col">주문 기업</th>
              <th scope="col">주문 제품</th>
              <th scope="col">주문 수량</th>
              <th scope="col">배정 창고</th>
              <th scope="col">배송 담당자</th>
              <th scope="col">입금 여부</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{{ jord_date }}</td>
              <td>{{ jordCodeDetail }}</td>
              <td>{{ pd_corp }}</td>
              <td>{{ pd_name }}</td>
              <td>{{ jord_amt }}</td>
              <td>{{ wh_name }}</td>
              <td>{{ name }}</td>
              <td>{{ jord_in }}</td>
            </tr>
          </tbody>
        </table>
        <div class="btn_areaC mt30">
          <a class="btn btn-primary mx-2" @click="modalClose()"
            ><span>닫기</span></a
          >
        </div>
      </dd>
    </dl>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';

export default {
  props: { dir_code: Number },
  data: function () {
    return {
      //DetailbordCode: this.bordCode,
      currentPage: 1,
      pageSize: 5,
      Detaildir_code: this.dir_code,
      jordCodeDetail: '',
      jord_date: '',
      pd_corp: '',
      name: '',
      pd_name: '',
      jord_amt: '',
      wh_name: '',
      jord_in: '',
    };
  },
  mounted() {
    this.search();
  },
  methods: {
    search: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      //params.append('DetailbordCode', this.DetailbordCode);
      params.append('currentPage', this.currentPage);
      params.append('pageSize', this.pageSize);
      params.append('dir_code', this.Detaildir_code);

      console;

      this.axios
        .post('/scm/shippingDirOne.do', params)
        .then(function (response) {
          console.log(response);
          vm.jordCodeDetail = response.data.result.jord_code;
          vm.jord_date = response.data.result.jord_date;
          vm.pd_corp = response.data.result.pd_corp;
          vm.name = response.data.result.name;
          vm.pd_name = response.data.result.pd_name;
          vm.jord_amt = response.data.result.jord_amt;
          vm.wh_name = response.data.result.wh_name;
          vm.jord_in = response.data.result.jord_in;
        })
        .catch(function (error) {
          alert('에러' + error);
        });
    },
    updBordDirection: function () {
      let vm = this; // eslint-disable-line no-unused-vars

      let params = new URLSearchParams(); // eslint-disable-line no-unused-vars
      //params.append('DetailbordCode', this.DetailbordCode);
      params.append('bordType', this.bordType);
      params.append('bordCode', this.DetailbordCode);

      console;

      this.axios
        .post('/pur/updateBorderDirection', params)
        .catch(function (error) {
          alert('에러' + error);
        });
      closeModal();
    },
    modalClose: function () {
      closeModal();
    },
  },
};
</script>

<style>
#grpInfo {
  border-collapse: separate;
  border-spacing: 20px;
}
#grpInfoWrap {
  background-color: #fff;
  padding: 3rem;
  border-radius: 10px;
  border: 2px solid rgb(59, 59, 59);
}
</style>
