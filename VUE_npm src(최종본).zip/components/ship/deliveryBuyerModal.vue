<template>
  <div id="deliveryModal">
    <strong style="font-size: 30px">{{ title }}</strong>
    <table class="row mt20">
      <caption>
        caption
      </caption>
      <colgroup>
        <col width="40px" />
        <col width="40px" />
        <col width="40px" />
        <col width="60px" />
        <col width="60px" />
        <col width="150px" />
      </colgroup>
      <tr>
        <th scope="row">주문번호</th>
        <td>
          <input
            style="text-align: center"
            type="text"
            class="inputTxt p100"
            v-model="jord_code"
            readonly="readonly"
          />
        </td>
        <th scope="row">주문고객</th>
        <td>
          <input
            style="text-align: center"
            type="text"
            class="inputTxt p100"
            v-model="company"
            readonly="readonly"
          />
        </td>
        <th scope="row">주문고객주소</th>
        <td>
          <input
            style="text-align: center"
            type="text"
            class="inputTxt p100"
            v-model="addr"
            readonly="readonly"
          />
        </td>
      </tr>
    </table>
    <br />
    <table class="col">
      <colgroup>
        <col width="6%" />
        <col width="4%" />
        <col width="4%" />
        <col width="8%" />
        <col width="15%" />
      </colgroup>
      <thead>
        <tr>
          <th scope="col">제품</th>
          <th scope="col">수량</th>
          <th scope="col">창고번호</th>
          <th scope="col">창고이름</th>
          <th scope="col">창고주소</th>
        </tr>
      </thead>
      <tbody>
        <td>{{ pd_name }}</td>
        <td>{{ jord_amt }}</td>
        <td>{{ wh_code }}</td>
        <td>{{ wh_name }}</td>
        <td>{{ wh_addr }}</td>
      </tbody>
    </table>

    <div class="btn_areaC mt30">
      <a
        v-on:click="insertDelHousing()"
        class="btn btn-primary"
        v-show="shType != '배송완료'"
        ><span>배송완료</span></a
      >
    </div>
  </div>
</template>
<script>
import { closeModal } from 'jenesius-vue-modal';

export default {
  // vue에서는 받아온 변수를 methods에서 직접 핸들링이 불가능하기 때문에
  // 임시 변수를 만들어서 받아온 변수를 넣어 줘야 함
  props: {
    title: String,
    code: Number,
  },
  data: function () {
    return {
      dirCode: this.code,
      pd_name: '',
      jord_amt: '',
      wh_code: '',
      wh_name: '',
      wh_addr: '',
      bordAmt: '',
      jord_code: '',
      company: '',
      addr: '',
      loginId: '',
      modelCode: '',
      shCode: '',
      shType: '',
    };
  },
  mounted: function () {
    let vm = this;
    let param = new URLSearchParams();

    param.append('dir_code', this.dirCode);

    console.log(this.dirCode);
    this.axios
      .post('/ship/deliveryListOne.do', param)
      .then(function (response) {
        console.log(response.data);

        vm.jord_code = response.data.result.jord_code;
        vm.company = response.data.result.company;
        vm.addr = response.data.result.addr;
        vm.pd_name = response.data.result.pd_name;
        vm.jord_amt = response.data.result.jord_amt;
        vm.wh_name = response.data.result.wh_name;
        vm.wh_code = response.data.result.wh_code;
        vm.wh_addr = response.data.result.wh_addr;
        vm.loginId = response.data.result.loginID;
        vm.modelCode = response.data.result.model_code;
        vm.shCode = response.data.result.sh_code;
        vm.shType = response.data.result.sh_type;
      })
      .catch(function (error) {
        alert('에러! API 요청에 오류가 있습니다. ' + error);
      });
  },
  methods: {
    // 재고처리 및 배송완료
    insertDelHousing: function () {
      console.log('insertDelHousing');

      let vm = this;
      let param = new URLSearchParams();

      param.append('jord_code', this.jord_code);
      param.append('wh_amt', this.jord_amt);
      param.append('wh_code', this.wh_code);
      param.append('ModelCode', this.modelCode);
      param.append('loginID', this.loginId);
      param.append('sh_code', this.shCode);

      this.axios
        .post('/ship/insertDelHousing.do', param)
        .then(function (response) {
          console.log(response.data);
          vm.$swal(response.data.resultMsg);
          closeModal(vm);
        })
        .catch(function (error) {
          alert('에러! API 요청에 오류가 있습니다. ' + error);
        });
    },
  },
  created() {
    // 자식요소에서 부모 요소 method 호출
  },
};
</script>

<style>
#deliveryModal {
  width: 66rem;
  background-color: #fff;
  padding: 3rem;
  border-radius: 10px;
  border: 2px solid rgb(59, 59, 59);
  text-align: center;
}
</style>
